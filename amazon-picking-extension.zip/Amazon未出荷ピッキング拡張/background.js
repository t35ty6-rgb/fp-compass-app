/**
 * Amazon 拡張 background service worker (v1.2.0)
 *   - bulk 送信 後 ZIP DL 検知 → content script に URL 送信
 *   - content script から の PDF 保存 request を chrome.downloads.download で 実行
 *     (Downloads folder 内 の sub-folder に 番号付き 名前 で 保存)
 */
chrome.downloads?.onCreated.addListener((item) => {
  if (!/sellercentral/.test(item.referrer || '') && !/sellercentral/.test(item.url || '')) return;
  const isZip = /\.zip/i.test(item.filename || '') || /application\/zip/i.test(item.mime || '') || /\.zip/i.test(item.url || '');
  if (!isZip) return;
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs[0];
    if (!tab) return;
    chrome.tabs.sendMessage(tab.id, { type: 'jobs_zip_download_detected', url: item.url, downloadId: item.id, filename: item.filename }).catch(() => {});
  });
});

// content script から の PDF 保存 request
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type !== 'jobs_save_pdf') return;
  const { filename, dataUrl } = msg;
  chrome.downloads.download({
    url: dataUrl,
    filename,
    conflictAction: 'uniquify',
    saveAs: false,
  }, (downloadId) => {
    if (chrome.runtime.lastError) {
      sendResponse({ ok: false, err: chrome.runtime.lastError.message });
    } else {
      sendResponse({ ok: true, downloadId });
    }
  });
  return true; // async response
});
