/**
 * Amazon 拡張 background service worker
 *   - 拡張 が bulk 送信 後 に ZIP DL を 検知 → URL を content script に 送信
 *   - content script 側 で unzip + 印刷
 */
chrome.downloads?.onCreated.addListener((item) => {
  if (!/sellercentral/.test(item.referrer || '') && !/sellercentral/.test(item.url || '')) return;
  const isZip = /\.zip/i.test(item.filename || '') || /application\/zip/i.test(item.mime || '') || /\.zip/i.test(item.url || '');
  if (!isZip) return;
  // active tab に URL 送信
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs[0];
    if (!tab) return;
    chrome.tabs.sendMessage(tab.id, { type: 'jobs_zip_download_detected', url: item.url, downloadId: item.id, filename: item.filename }).catch(() => {});
  });
});
