const $ = (id) => document.getElementById(id);
const status = $('status');

async function callInTab(funcName, statusMsg) {
  status.className = '';
  status.textContent = statusMsg;
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !/sellercentral\.amazon\./.test(tab.url || '')) {
      throw new Error('セラーセントラル page で 押して ください');
    }
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: async (fn) => {
        if (typeof window[fn] !== 'function') return { ok: false, error: `${fn} 未 load、 page reload 試して` };
        return await window[fn]();
      },
      args: [funcName],
    });
    if (!result || !result.ok) throw new Error(result?.error || '不明 エラー');
    return result;
  } catch (e) {
    status.textContent = 'エラー: ' + e.message;
    status.className = 'err';
    throw e;
  }
}

$('btn-picking').onclick = async () => {
  try {
    const r = await callInTab('__jobsPickingRun', '未出荷 scrape 中…');
    let msg = `✓ ${r.itemCount} 商品 / ${r.orderCount} 件 印刷 開始`;
    if (r.cancelRequestedCount) msg += ` (キャンセル依頼 ${r.cancelRequestedCount}件 除外)`;
    status.textContent = msg;
    status.className = 'ok';
  } catch {}
};

$('btn-bulk').onclick = async () => {
  try {
    // bulk page なら 自動 fill、 未出荷 page なら 統合 flow
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const isBulkPage = /\/bulk-buy-shipping\//.test(tab?.url || '');
    if (isBulkPage) {
      const r = await callInTab('__jobsBulkAutoFill', 'bulk fill 中 (SKU size prompt が 出るかも)…');
      status.textContent = `✓ 送信: ${r.orderCount} 件、 送料 合計 ¥${r.total}`;
      status.className = 'ok';
    } else {
      const r = await callInTab('__jobsCombinedBulk', 'checkbox 選択 → bulk page へ 遷移 中…');
      status.textContent = `✓ ${r.selected} 件 選択 (キャンセル依頼 ${r.excluded} 件 除外) → bulk page で 自動 fill 起動 中`;
      status.className = 'ok';
    }
  } catch {}
};

$('btn-cancel').onclick = async () => {
  try {
    const r = await callInTab('__jobsBulkCancelApprove', 'キャンセル 対象 検索 中…');
    status.textContent = `✓ ${r.targetCount} 件 対象。 ${r.note || ''}`;
    status.className = 'ok';
  } catch {}
};
