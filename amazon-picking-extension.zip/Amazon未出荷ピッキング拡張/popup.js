const $ = (id) => document.getElementById(id);
const status = $('status');

async function callInTab(funcName, statusMsg) {
  status.className = '';
  status.textContent = statusMsg;
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !/sellercentral\.amazon\./.test(tab.url || '')) {
      throw new Error('セラーセントラル page で 押して ください');
    }
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: async (fn) => {
        if (typeof window[fn] !== 'function') return { ok: false, error: `${fn} 未 load、 page reload 試して` };
        return await window[fn]();
      },
      args: [funcName],
    });
    if (!result || !result.ok) throw new Error(result?.error || '不明 エラー');
    return result;
  } catch (e) {
    status.textContent = 'エラー: ' + e.message;
    status.className = 'err';
    throw e;
  }
}

$('run-picking').onclick = async () => {
  try {
    const r = await callInTab('__jobsPickingRun', '実行 中… 未出荷 scrape');
    status.textContent = `完了: ${r.itemCount} 商品 / ${r.orderCount} 件 — 別 tab で 印刷 preview`;
    status.className = 'ok';
  } catch {}
};

$('run-bulk').onclick = async () => {
  try {
    await callInTab('__jobsGoBulk', '未出荷 選択 → bulk page 遷移 中…');
    status.textContent = '遷移 完了。 遷移 先 で 「③ 自動 fill」 押して';
    status.className = 'ok';
  } catch {}
};

$('run-bulk-fill').onclick = async () => {
  try {
    const r = await callInTab('__jobsBulkAutoFill', 'bulk fill 中… (SKU サイズ prompt 出るかも)');
    status.textContent = `購入 実行: ${r.orderCount} 件、 送料 合計 ¥${r.total}`;
    status.className = 'ok';
  } catch {}
};
