const btn = document.getElementById('run');
const status = document.getElementById('status');

btn.addEventListener('click', async () => {
  btn.disabled = true;
  status.textContent = '実行中… ページ 巡回 中';
  status.className = '';

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !/sellercentral\.amazon\./.test(tab.url || '')) {
      throw new Error('セラーセントラル 未出荷 page で 押して ください');
    }

    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: async () => {
        if (typeof window.__jobsPickingRun !== 'function') {
          return { ok: false, error: 'content.js 未 load、 page を reload して 再試行' };
        }
        return await window.__jobsPickingRun();
      }
    });

    if (!result || !result.ok) {
      throw new Error(result?.error || '不明 エラー');
    }
    status.textContent = `完了: ${result.itemCount} 商品 / ${result.orderCount} 件\n印刷 preview を 別 tab で 開いた`;
    status.className = 'ok';
  } catch (e) {
    status.textContent = 'エラー: ' + e.message;
    status.className = 'err';
  } finally {
    btn.disabled = false;
  }
});
