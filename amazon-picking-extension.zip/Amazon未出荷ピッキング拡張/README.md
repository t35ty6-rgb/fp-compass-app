# Amazon 未出荷 ピッキングリスト 拡張

セラーセントラルの **注文管理 > 未出荷** page で button 1発 → 全 page scrape → 商品別 sort → A4 印刷 preview 自動 open。

## 使い方

1. Chrome → `chrome://extensions` を 開く
2. 右上 「デベロッパーモード」 ON
3. 「パッケージ化されていない拡張機能を読み込む」 → この dir (`Amazon未出荷ピッキング拡張/`) を 選択
4. Chrome 右上 の ツールバー に 「Jobs ピッキングリスト」 アイコン が 追加される
5. セラーセントラル の 未出荷 page を 開く
6. アイコン click → popup の 「未出荷 全件 スクレイプ → 印刷」 button 押す
7. 別 tab で 印刷 preview 自動 open → ⌘P で 印刷

## 現状

- **v0.1** = SELECTOR 未確定 (一般的な Amazon SC pattern を 推定)
- owner が 実 未出荷 page の 注文 table を **F12 → 該当 tr / row 選択 → 右クリック 「Copy outerHTML」** して 貼付 したら、 Jobs が selector 修正 → v0.2
- 3ストア (どれ でも) の 未出荷 で 動く 想定

## 対応 URL

- `https://sellercentral.amazon.co.jp/*`
- `https://sellercentral.amazon.com/*`

## 出力 layout

```
━━━━━ ピッキングリスト 2026-08-27 (木) 未出荷 12件 ━━━━━

■ 商品A 桜柄  ×5個
   1. 山田 太郎   ×1   #123-4567890
   2. 佐藤 花子   ×2   #123-4567891
   3. 鈴木 一郎   ×1   #123-4567892
   4. 田中 次郎   ×1   #123-4567893

■ 商品B 無地 白  ×3個
   1. 高橋 三郎   ×2   #123-4567894
   ...
```

## selector 修正 手順 (v0.2 以降)

owner から outerHTML 貰ったら `content.js` の `SEL` block を 実 class名 に 差替:
- `SEL.orderRow` — 各 注文 row を 特定 する selector
- `SEL.buyerName`, `SEL.productName`, `SEL.quantity`, `SEL.orderId`
- `SEL.nextPage` — pagination の 次 page button
