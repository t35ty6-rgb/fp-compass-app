/**
 * Jobs ピッキング + 伝票 自動 拡張 (v0.4)
 *
 * page 判定 で 2 mode に 分岐:
 *   A. 未出荷 一覧 (/orders-v3/ref=xx_myo_favb_xx?shipByDate=all)
 *      → 商品別 ピッキングリスト A4 印刷 (v0.3 継承 + 写真付)
 *      → popup に 「続けて 伝票 購入」 button で bulk-buy-shipping へ 遷移
 *   B. bulk-buy-shipping (/orders-v3/bulk-buy-shipping/ORDER1;ORDER2;...)
 *      → 各 order の SKU 見て chrome.storage の size preset 適用
 *      → 未登録 SKU は modal で 「この 商品 サイズ 何?」 popup
 *      → 全 order fill 後 summary → owner が 「確認 実行」 → Amazon submit
 *      → PDF DL + 印刷 は Amazon 側 が 自動 提供 する
 *
 * size preset (owner 明示 2026-08-27):
 *   ネコポス: 23 × 12 × 2 cm, 100 g
 *   60サイズ:  20 × 20 × 20 cm, 500 g
 *   80サイズ:  25 × 25 × 25 cm, 1500 g
 *   100サイズ: 30 × 30 × 30 cm, 3000 g
 *   120サイズ: 35 × 35 × 30 cm, 5000 g
 */

(function () {
  'use strict';

  document.documentElement.setAttribute('data-jobs-picking-loaded', 'v1.0');

  const sleep = (ms) => new Promise(r => setTimeout(r, ms));
  const log = (...a) => console.log('[Jobs Ext]', ...a);

  // ═══ size preset ═══════════════════════════════════════════
  const SIZE_PRESETS = {
    'ネコポス':   { length: 23, width: 12, height: 2,  weight_g: 100  },
    '60サイズ':   { length: 20, width: 20, height: 20, weight_g: 500  },
    '80サイズ':   { length: 25, width: 25, height: 25, weight_g: 1500 },
    '100サイズ':  { length: 30, width: 30, height: 30, weight_g: 3000 },
    '120サイズ':  { length: 35, width: 35, height: 30, weight_g: 5000 },
  };

  // ═══ storage helpers (chrome.storage.local) ═══════════════
  async function getSkuSize(sku) {
    if (!sku) return null;
    return new Promise(resolve => {
      chrome.storage.local.get('sku_sizes', (data) => {
        resolve(data.sku_sizes?.[sku] || null);
      });
    });
  }
  async function saveSkuSize(sku, sizeName) {
    return new Promise(resolve => {
      chrome.storage.local.get('sku_sizes', (data) => {
        const sizes = data.sku_sizes || {};
        sizes[sku] = sizeName;
        chrome.storage.local.set({ sku_sizes: sizes }, resolve);
      });
    });
  }
  async function saveOrderInfo(map) {
    if (typeof chrome === 'undefined' || !chrome.storage?.local) return;
    return new Promise(resolve => {
      chrome.storage.local.get('order_info', (data) => {
        const merged = Object.assign({}, data.order_info || {}, map);
        chrome.storage.local.set({ order_info: merged }, resolve);
      });
    });
  }
  async function getOrderInfo(orderId) {
    if (typeof chrome === 'undefined' || !chrome.storage?.local) return null;
    return new Promise(resolve => {
      chrome.storage.local.get('order_info', (data) => {
        resolve(data.order_info?.[orderId] || null);
      });
    });
  }

  // ═══ batch size prompt modal (v1.0、 全 未登録 SKU を 一度 に) ════
  function showBatchSizePrompt(items) {
    // items = [{sku, product, imgUrl}, ...]  重複 SKU は 事前 に dedup 済 前提
    return new Promise(resolve => {
      const overlay = document.createElement('div');
      overlay.id = 'jobs-batch-size-modal';
      overlay.style.cssText = `position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:2147483647;display:flex;align-items:center;justify-content:center;font-family:-apple-system,"Hiragino Kaku Gothic ProN",sans-serif;`;
      const presetOptsHtml = (name) => Object.entries(SIZE_PRESETS).map(([n, p], i) => `
        <label style="display:inline-block;padding:6px 10px;border:1px solid #ddd;border-radius:4px;margin:0 4px 4px 0;cursor:pointer;font-size:12px;">
          <input type="radio" name="size-${name}" value="${n}" ${i === 0 ? 'checked' : ''} style="margin-right:4px;"> ${n}
        </label>
      `).join('');
      const itemsHTML = items.map((it, idx) => `
        <div style="border:1px solid #ddd;border-radius:6px;padding:10px;margin-bottom:10px;">
          <div style="display:flex;gap:10px;align-items:center;margin-bottom:6px;">
            ${it.imgUrl ? `<img src="${escapeHtml(it.imgUrl)}" style="width:48px;height:48px;object-fit:contain;background:#fff;border:1px solid #ccc;">` : '<div style="width:48px;height:48px;background:#eee;"></div>'}
            <div style="flex:1;min-width:0;">
              <div style="font-weight:600;font-size:13px;line-height:1.4;">${escapeHtml(it.product)}</div>
              <div style="font-family:monospace;font-size:11px;color:#666;margin-top:2px;">SKU: ${escapeHtml(it.sku)} <span style="color:#999;">(${it.orderCount || 1}件 の 注文)</span></div>
            </div>
          </div>
          <div data-sku="${escapeHtml(it.sku)}">
            ${presetOptsHtml(escapeHtml(it.sku))}
          </div>
        </div>
      `).join('');
      overlay.innerHTML = `
        <div style="background:#fff;padding:24px;border-radius:10px;max-width:640px;width:92%;max-height:85vh;overflow:auto;box-shadow:0 10px 40px rgba(0,0,0,0.3);">
          <h2 style="margin:0 0 12px;font-size:16px;color:#232F3E;">未 登録 商品 の サイズ を まとめて 選択 (${items.length}件)</h2>
          <div style="background:#EEF6FF;border-left:4px solid #0077CC;padding:10px 14px;margin-bottom:16px;font-size:12px;">
            これ以外 の 商品 は 過去 の 登録 で 自動 fill する。 各 商品 サイズ を 選んで 「まとめて 適用」 を 押す と 一気 に 進む。
          </div>
          ${itemsHTML}
          <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:16px;">
            <button id="jbs-skip" style="padding:10px 16px;border:1px solid #ccc;background:#fff;border-radius:6px;cursor:pointer;">全部 スキップ (Amazon UI で 手動)</button>
            <button id="jbs-ok" style="padding:10px 20px;border:0;background:#FF9900;color:#000;font-weight:600;border-radius:6px;cursor:pointer;">まとめて 適用 (${items.length}件)</button>
          </div>
        </div>
      `;
      document.body.appendChild(overlay);
      overlay.querySelector('#jbs-ok').onclick = () => {
        const result = {};
        items.forEach(it => {
          const radio = overlay.querySelector(`input[name="size-${CSS.escape(it.sku)}"]:checked`);
          result[it.sku] = radio?.value || null;
        });
        document.body.removeChild(overlay);
        resolve(result);
      };
      overlay.querySelector('#jbs-skip').onclick = () => {
        document.body.removeChild(overlay);
        resolve({});
      };
    });
  }

  // ═══ (deprecated in v1.0 but kept for backward compat) 単発 size prompt ═══
  function showSizePrompt(productName, sku, imgUrl) {
    return new Promise(resolve => {
      const overlay = document.createElement('div');
      overlay.id = 'jobs-size-modal';
      overlay.style.cssText = `position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.6);z-index:2147483647;display:flex;align-items:center;justify-content:center;font-family:-apple-system,"Hiragino Kaku Gothic ProN",sans-serif;`;
      const opts = Object.entries(SIZE_PRESETS).map(([name, p], i) => `
        <label style="display:block;padding:10px 12px;border:1px solid #ddd;border-radius:6px;margin-bottom:6px;cursor:pointer;font-size:14px;">
          <input type="radio" name="jobs-size" value="${name}" ${i === 0 ? 'checked' : ''} style="margin-right:8px;">
          <strong>${name}</strong>
          <span style="color:#666;font-size:12px;margin-left:8px;">${p.length}×${p.width}×${p.height}cm / ${p.weight_g}g</span>
        </label>
      `).join('');
      overlay.innerHTML = `
        <div style="background:#fff;padding:24px;border-radius:10px;max-width:560px;width:90%;box-shadow:0 10px 40px rgba(0,0,0,0.3);">
          <h2 style="margin:0 0 16px;font-size:16px;color:#232F3E;">この 商品 の 配送 サイズ は?</h2>
          <div style="display:flex;gap:12px;padding:10px;background:#F5F5F5;border-radius:6px;margin-bottom:16px;align-items:center;">
            ${imgUrl ? `<img src="${imgUrl}" style="width:60px;height:60px;object-fit:contain;background:#fff;border:1px solid #ccc;">` : ''}
            <div style="flex:1;min-width:0;">
              <div style="font-weight:600;font-size:13px;line-height:1.4;">${escapeHtml(productName)}</div>
              <div style="font-family:monospace;font-size:11px;color:#666;margin-top:4px;">SKU: ${escapeHtml(sku)}</div>
            </div>
          </div>
          <form id="jobs-size-form" style="margin:0 0 16px;">
            ${opts}
          </form>
          <div style="display:flex;gap:8px;justify-content:flex-end;">
            <button id="jobs-size-skip" style="padding:10px 16px;border:1px solid #ccc;background:#fff;border-radius:6px;cursor:pointer;">スキップ (この 商品 は 手動)</button>
            <button id="jobs-size-ok" style="padding:10px 20px;border:0;background:#FF9900;color:#000;font-weight:600;border-radius:6px;cursor:pointer;">OK</button>
          </div>
          <div style="font-size:11px;color:#888;margin-top:12px;text-align:center;">選択 は 保存 されて、 次回 同 SKU では 聞かれ ません。</div>
        </div>
      `;
      document.body.appendChild(overlay);

      overlay.querySelector('#jobs-size-ok').onclick = () => {
        const val = overlay.querySelector('input[name="jobs-size"]:checked')?.value;
        document.body.removeChild(overlay);
        resolve(val || null);
      };
      overlay.querySelector('#jobs-size-skip').onclick = () => {
        document.body.removeChild(overlay);
        resolve(null);
      };
    });
  }

  // ═══ confirm summary modal (v0.5: 商品別 group + 写真付) ═══════════════
  function showConfirmModal(summary) {
    return new Promise(resolve => {
      // 商品別 group + 個数多い順 sort (picking list と 同 順)
      const groupMap = new Map();
      summary.orders.forEach(o => {
        const k = o.product || '(不明)';
        if (!groupMap.has(k)) groupMap.set(k, []);
        groupMap.get(k).push(o);
      });
      // 各 group 内 は 個数 (size 分 の cost 合計) 多い 順、 group 間 は 件数 多い 順
      const groups = Array.from(groupMap.entries()).map(([product, arr]) => ({
        product,
        arr,
        totalCost: arr.reduce((s, x) => s + parseInt(x.cost || '0', 10), 0),
      })).sort((a, b) => b.arr.length - a.arr.length);

      const overlay = document.createElement('div');
      overlay.style.cssText = `position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:2147483647;display:flex;align-items:center;justify-content:center;font-family:-apple-system,"Hiragino Kaku Gothic ProN",sans-serif;`;

      const groupsHTML = groups.map((g, gi) => {
        const rows = g.arr.map((o, i) => `
          <tr>
            <td style="padding:6px 8px;border-bottom:1px solid #eee;font-size:11px;color:#999;text-align:right;width:24px;">${i + 1}</td>
            <td style="padding:6px 8px;border-bottom:1px solid #eee;font-size:12px;">${escapeHtml(o.buyer || '—')}</td>
            <td style="padding:6px 8px;border-bottom:1px solid #eee;font-size:11px;font-family:monospace;color:#666;">${escapeHtml(o.orderId)}</td>
            <td style="padding:6px 8px;border-bottom:1px solid #eee;font-size:12px;">${escapeHtml(o.size || '—')}</td>
            <td style="padding:6px 8px;border-bottom:1px solid #eee;font-size:12px;text-align:right;font-variant-numeric:tabular-nums;">¥${o.cost || '—'}</td>
          </tr>
        `).join('');
        return `
          <div style="margin-bottom:14px;border:1px solid #ddd;border-radius:6px;overflow:hidden;">
            <div style="display:grid;grid-template-columns:44px 1fr;gap:8px;padding:6px 10px;background:#F5F5F5;border-bottom:1px solid #ddd;align-items:center;">
              ${g.arr[0]?.imgUrl ? `<img src="${escapeHtml(g.arr[0].imgUrl)}" style="width:40px;height:40px;object-fit:contain;background:#fff;border:1px solid #ccc;">` : '<div style="width:40px;height:40px;background:#eee;border:1px dashed #ccc;"></div>'}
              <div>
                <div style="font-weight:600;font-size:13px;">■ ${escapeHtml(g.product)}</div>
                <div style="font-size:11px;color:#666;">${g.arr.length}件 / ¥${g.totalCost}</div>
              </div>
            </div>
            <table style="width:100%;border-collapse:collapse;">${rows}</table>
          </div>
        `;
      }).join('');
      overlay.innerHTML = `
        <div style="background:#fff;padding:24px;border-radius:10px;max-width:820px;width:92%;max-height:85vh;overflow:auto;box-shadow:0 10px 40px rgba(0,0,0,0.3);">
          <h2 style="margin:0 0 12px;font-size:16px;color:#232F3E;">配送 ラベル 一括 購入 確認 (商品別 sort)</h2>
          <div style="background:#FFF3E0;border-left:4px solid #FF9900;padding:10px 14px;margin-bottom:16px;font-size:13px;">
            <strong>${summary.orders.length}件</strong> / 合計 <strong>¥${summary.total}</strong> の 配送 ラベル を 購入 → 実行 後 は 拡張 が 各 label PDF を 自動 open → 印刷 dialog へ
          </div>
          ${groupsHTML}
          ${summary.errors.length ? `
            <div style="background:#FEE;border-left:4px solid #D00;padding:10px 14px;margin:10px 0;font-size:12px;">
              <strong>⚠ ${summary.errors.length}件 fill 失敗</strong>: Amazon UI で 手動 確認 要
              <ul style="margin:6px 0 0;padding-left:20px;">
                ${summary.errors.map(e => `<li>${escapeHtml(e.orderId)} — ${escapeHtml(e.reason)}</li>`).join('')}
              </ul>
            </div>
          ` : ''}
          <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:16px;padding-top:12px;border-top:1px solid #eee;">
            <button id="jobs-cancel" style="padding:10px 16px;border:1px solid #ccc;background:#fff;border-radius:6px;cursor:pointer;">キャンセル</button>
            <button id="jobs-confirm" style="padding:10px 20px;border:0;background:#D00;color:#fff;font-weight:600;border-radius:6px;cursor:pointer;">${summary.errors.length ? '成功分 のみ' : '全件'} 実行 (¥${summary.total} 課金) + PDF 自動印刷</button>
          </div>
        </div>
      `;
      document.body.appendChild(overlay);
      overlay.querySelector('#jobs-cancel').onclick = () => { document.body.removeChild(overlay); resolve(false); };
      overlay.querySelector('#jobs-confirm').onclick = () => { document.body.removeChild(overlay); resolve(true); };
    });
  }

  function escapeHtml(s) {
    return String(s || '').replace(/[&<>"']/g, c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));
  }

  // ═══ 未出荷 一覧 page: picking list ═══════════════════════
  function parseUnshippedRow(row) {
    const text = (row.innerText || '').replace(/\s+/g, ' ').trim();
    const buyer = row.querySelector('[data-test-id="buyer-name-with-link"]')?.innerText?.trim() || '';
    const orderIdEl = row.querySelector('.cell-body-title a[href*="/orders-v3/order/"]');
    const orderId = orderIdEl?.innerText?.trim() || text.match(/\d{3}-\d{7}-\d{7}/)?.[0] || '';
    const productCell = row.querySelector('.myo-list-orders-product-name-cell');
    if (!productCell) return null;
    const cellText = productCell.innerText || '';
    const product = productCell.querySelector('a[href*="/gp/product/"] div')?.innerText?.trim() ||
                    cellText.split('\n')[0]?.trim() || '';
    let imgUrl = row.querySelector('.myo-list-orders-product-image-cell img')?.src || '';
    if (imgUrl) imgUrl = imgUrl.replace(/_SR\d+,\d+_/, '_SR300,300_').replace(/_SL\d+_/, '_SL300_');
    const asin = cellText.match(/ASIN[:：]\s*([A-Z0-9]{10})/)?.[1] || '';
    const sku = cellText.match(/SKU[:：]\s*(\S+)/)?.[1] || '';
    const qty = parseInt(cellText.match(/数量[:：]\s*(\d+)/)?.[1] || '1', 10);
    const cancelRequested = /キャンセルをリクエスト|注文のキャンセル/.test(text);
    if (!product || !buyer) return null;
    return { buyer, product, qty, orderId, asin, sku, imgUrl, cancelRequested };
  }

  async function setMaxPageSize() {
    const sel = document.querySelector('select#myo-table-results-per-page');
    if (!sel || sel.value === '100') return false;
    sel.value = '100';
    sel.dispatchEvent(new Event('change', { bubbles: true }));
    await sleep(3000);
    return true;
  }
  async function clickNextPage() {
    const nextLi = document.querySelector('ul.a-pagination li.a-last');
    if (!nextLi || nextLi.classList.contains('a-disabled')) return false;
    const link = nextLi.querySelector('a');
    if (!link) return false;
    link.click();
    return true;
  }
  function scrapePage() {
    const rows = document.querySelectorAll('table#orders-table tbody tr');
    const items = [];
    rows.forEach(row => { const p = parseUnshippedRow(row); if (p) items.push(p); });
    return items;
  }
  async function scrapeAllUnshipped(maxPages = 30) {
    if (await setMaxPageSize()) await sleep(2000);
    let all = [];
    for (let i = 0; i < maxPages; i++) {
      await sleep(500);
      all = all.concat(scrapePage());
      if (!(await clickNextPage())) break;
      await sleep(2500);
    }
    return all;
  }

  function groupAndSort(items) {
    const groups = new Map();
    items.forEach(it => {
      if (!groups.has(it.product)) groups.set(it.product, []);
      groups.get(it.product).push(it);
    });
    for (const arr of groups.values()) {
      arr.sort((a, b) => (b.qty - a.qty) || a.buyer.localeCompare(b.buyer, 'ja'));
    }
    return Array.from(groups.entries()).map(([product, arr]) => ({
      product, total: arr.reduce((s, x) => s + x.qty, 0),
      asin: arr[0]?.asin || '', sku: arr[0]?.sku || '', imgUrl: arr[0]?.imgUrl || '',
      buyers: arr,
    })).sort((a, b) => b.total - a.total);
  }

  function buildPickingHTML(groups, cancelRequested = []) {
    const t = new Date();
    const dateStr = `${t.getFullYear()}-${String(t.getMonth()+1).padStart(2,'0')}-${String(t.getDate()).padStart(2,'0')}`;
    const weekday = ['日','月','火','水','木','金','土'][t.getDay()];
    const totalItems = groups.reduce((s,g) => s+g.total, 0);
    const totalOrders = groups.reduce((s,g) => s+g.buyers.length, 0);
    const cancelHTML = cancelRequested.length ? `
      <section style="margin-top:16px;padding:10px 14px;background:#FEF3E0;border-left:4px solid #FF9900;border-radius:4px;">
        <strong>⚠ キャンセル 依頼 ${cancelRequested.length}件 (梱包 対象 外)</strong>
        <ul style="margin:6px 0 0;padding-left:20px;font-size:10pt;">
          ${cancelRequested.map(c => `<li>${escapeHtml(c.buyer)} 様 — ${escapeHtml(c.product.slice(0,40))} #${escapeHtml(c.orderId)}</li>`).join('')}
        </ul>
      </section>
    ` : '';
    const groupsHTML = groups.map(g => `
      <section class="group">
        <div class="group-head">
          ${g.imgUrl ? `<img class="thumb" src="${escapeHtml(g.imgUrl)}" alt="" crossorigin="anonymous">` : '<div class="thumb thumb-blank"></div>'}
          <div class="group-title">
            <h2><span class="pname">${escapeHtml(g.product)}</span><span class="qty">×${g.total}個</span></h2>
            ${g.asin || g.sku ? `<div class="meta">${g.asin ? `ASIN ${escapeHtml(g.asin)}` : ''}${g.asin && g.sku ? '  /  ' : ''}${g.sku ? `SKU ${escapeHtml(g.sku)}` : ''}</div>` : ''}
          </div>
        </div>
        <ol>${g.buyers.map((b,i)=>`<li><span class="num">${i+1}.</span><span class="buyer">${escapeHtml(b.buyer)} 様</span><span class="q">×${b.qty}</span><span class="oid">${escapeHtml(b.orderId)}</span></li>`).join('')}</ol>
      </section>
    `).join('');
    return `<!DOCTYPE html><html lang="ja"><head><meta charset="UTF-8"><title>ピッキングリスト ${dateStr}</title>
<style>
  @page { size: A4 portrait; margin: 12mm; }
  *{box-sizing:border-box;} body{font-family:-apple-system,"Hiragino Kaku Gothic ProN","Yu Gothic",sans-serif;color:#111;margin:0;padding:0;font-size:11pt;line-height:1.5;}
  header{border-bottom:2px solid #000;padding:0 0 6px;margin-bottom:12px;display:flex;justify-content:space-between;align-items:baseline;}
  h1{font-size:14pt;margin:0;font-weight:700;} .meta-header{font-size:10pt;color:#444;}
  .group{break-inside:avoid;page-break-inside:avoid;margin-bottom:14px;border:1px solid #ddd;border-radius:4px;overflow:hidden;}
  .group-head{display:grid;grid-template-columns:64px 1fr;gap:10px;padding:6px 8px;background:#F5F5F5;border-bottom:1px solid #ddd;align-items:center;}
  .thumb{width:60px;height:60px;object-fit:contain;background:#fff;border:1px solid #ccc;} .thumb-blank{background:#EEE;border:1px dashed #ccc;}
  .group-title{min-width:0;} h2{font-size:12pt;margin:0;padding:0;background:transparent;border-left:0;display:flex;justify-content:space-between;align-items:baseline;font-weight:700;}
  h2 .pname{flex:1;padding-right:12px;word-break:break-word;} h2 .qty{font-weight:700;white-space:nowrap;}
  .meta{font-size:9pt;color:#666;padding:2px 0 0;font-family:"SF Mono",Menlo,monospace;}
  ol{margin:0;padding:0;list-style:none;} li{padding:4px 10px;border-bottom:1px dotted #ccc;display:grid;grid-template-columns:24px 1fr 60px 200px;gap:8px;align-items:baseline;font-variant-numeric:tabular-nums;}
  li:last-child{border-bottom:0;} .num{color:#999;font-size:10pt;text-align:right;} .buyer{font-weight:500;} .q{text-align:right;font-weight:700;} .oid{font-family:"SF Mono",Menlo,monospace;font-size:9pt;color:#666;}
  footer{margin-top:16px;padding-top:6px;border-top:1px solid #999;text-align:right;font-size:10pt;color:#666;}
  .print-btn{position:fixed;top:12px;right:12px;padding:10px 16px;background:#FF9900;color:#000;border:0;border-radius:6px;cursor:pointer;font-weight:600;box-shadow:0 2px 6px rgba(0,0,0,0.2);}
  @media print{.print-btn{display:none!important;}}
</style></head><body>
<button class="print-btn" onclick="window.print()">印刷 (⌘P)</button>
<header><h1>ピッキングリスト</h1><div class="meta-header">${dateStr} (${weekday}) — 未出荷 ${totalOrders}件 / 合計 ${totalItems}個</div></header>
${groupsHTML}
${cancelHTML}
<footer>合計 ${totalItems}個 / ${totalOrders}件 — Jobs ピッキング拡張 v1.0.5</footer>
<script>setTimeout(() => window.print(), 500);</script>
</body></html>`;
  }

  async function runPickingList() {
    log('picking list start');
    const allItems = await scrapeAllUnshipped();
    if (allItems.length === 0) return { ok: false, error: '未出荷 row 検出 ゼロ' };

    // キャンセル 依頼 order は 梱包 しない ので 除外
    const cancelRequested = allItems.filter(it => it.cancelRequested);
    const items = allItems.filter(it => !it.cancelRequested);

    // orderId → buyer/product/img/sku 対応表 を storage 保存 (bulk 側 で 参照)
    const orderInfoMap = {};
    allItems.forEach(it => {
      orderInfoMap[it.orderId] = { buyer: it.buyer, product: it.product, sku: it.sku, imgUrl: it.imgUrl, cancelRequested: it.cancelRequested };
    });
    await saveOrderInfo(orderInfoMap);
    log(`orderInfo 保存: ${Object.keys(orderInfoMap).length} 件 (キャンセル依頼 ${cancelRequested.length}件)`);

    const groups = groupAndSort(items);
    const html = buildPickingHTML(groups, cancelRequested);
    const blob = new Blob([html], { type: 'text/html' });
    window.open(URL.createObjectURL(blob), '_blank');
    return { ok: true, itemCount: groups.length, orderCount: items.length, cancelRequestedCount: cancelRequested.length };
  }

  // ═══ 未出荷 → bulk-buy-shipping 遷移 ═══════════════════════
  //   キャンセル 依頼 order は checkbox 選択 対象 から 除外
  async function goToBulkBuyShipping() {
    log('bulk-buy-shipping 遷移 開始');
    // 各 row を 見て、 cancel 依頼 でない 行 の checkbox だけ click
    const rows = document.querySelectorAll('table#orders-table tbody tr');
    let selected = 0, excluded = 0;
    rows.forEach(row => {
      const cb = row.querySelector('input[type="checkbox"]');
      if (!cb) return;
      const text = row.innerText || '';
      if (/キャンセルをリクエスト|注文のキャンセル/.test(text)) {
        if (cb.checked) cb.click();
        excluded++;
      } else {
        if (!cb.checked) cb.click();
        selected++;
      }
    });
    await sleep(1200);
    log(`checked: ${selected} (cancel 依頼 除外 ${excluded})`);
    // link 取得
    const bulkLink = document.querySelector('[data-test-id="ab-bulk-buy-shipping"] a[href*="bulk-buy-shipping"]');
    if (!bulkLink) return { ok: false, error: 'bulk-buy-shipping link 見つからず (checkbox 未選択?)' };
    // 統合 flow の 継続 flag を storage に (bulk page で 拡張 が 検知 して auto-fill 発動)
    await new Promise(res => {
      if (typeof chrome === 'undefined' || !chrome.storage?.local) return res();
      chrome.storage.local.set({ jobs_in_bulk_flow: { started: Date.now(), source: 'combined_button' } }, res);
    });
    log('bulk link, jump:', bulkLink.href);
    location.href = bulkLink.href;
    return { ok: true, selected, excluded };
  }

  // 統合 flow: 未出荷 → bulk 遷移 → auto-fill を 1 click で
  async function runCombinedBulk() {
    const res = await goToBulkBuyShipping();
    // location.href = ... で page 遷移 する ので この 後 の code は 走ら ない、
    // bulk page 側 で jobs_in_bulk_flow flag を 見て auto-fill 起動
    return res;
  }

  // ═══ bulk-buy-shipping page: 自動 fill ═══════════════════
  function findOrderRows() {
    // 各 order は <tr> で 囲まれ、 中 に order id リンク + weight.kg/g + dimension.length/width/height を 持つ
    const rows = [];
    document.querySelectorAll('a[href*="/orders-v3/order/"][target="_blank"]').forEach(a => {
      const orderId = a.innerText.trim();
      if (!/^\d{3}-\d{7}-\d{7}$/.test(orderId)) return;
      // 一番 近い <tr> を 探す
      let tr = a.closest('tr');
      // 上位 tr が form field を 含まない case あり → 更に 上 の tr を 使う
      while (tr && !tr.querySelector('input[name="dimension.length"]') && !tr.querySelector('input[name="weight.g"]')) {
        tr = tr.parentElement?.closest('tr') || null;
      }
      if (tr) rows.push({ orderId, row: tr });
    });
    return rows;
  }

  function extractSectionSku(row) {
    const text = row.innerText || '';
    // Amazon SKU は 英数字 + 一部 記号。 「数量」 の 「数」 で 止まる ため に non-ascii は 除外
    return text.match(/SKU[:\s]*([A-Za-z0-9_\-\.]+)/)?.[1] || '';
  }
  function extractSectionProduct(row) {
    const text = row.innerText || '';
    // SKU の 直前 の 行 が 商品名
    const lines = text.split('\n').map(s => s.trim()).filter(Boolean);
    const skuIdx = lines.findIndex(l => /^SKU/.test(l));
    if (skuIdx > 0) return lines[skuIdx - 1];
    return lines[1] || '';
  }
  function extractSectionImg(row) {
    return row.querySelector('img')?.src || '';
  }

  // React/Vue controlled input を bypass する native setter (Amazon の AnyUI 対策)
  const _nativeInputSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
  const _nativeSelectSetter = Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, 'value').set;
  function setInputValueNative(el, val) {
    if (!el) return false;
    _nativeInputSetter.call(el, String(val));
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    return true;
  }
  function setSelectValueNative(el, val) {
    if (!el) return false;
    _nativeSelectSetter.call(el, String(val));
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    return true;
  }

  function fillOrderDimensions(row, preset) {
    const okL = setInputValueNative(row.querySelector('input[name="dimension.length"]'), preset.length);
    const okW = setInputValueNative(row.querySelector('input[name="dimension.width"]'), preset.width);
    const okH = setInputValueNative(row.querySelector('input[name="dimension.height"]'), preset.height);
    const okG = setInputValueNative(row.querySelector('input[name="weight.g"]'), preset.weight_g);
    const okKg = setInputValueNative(row.querySelector('input[name="weight.kg"]'), 0);
    return okL && okW && okH && okG;
  }

  // v1.0.5: Amazon は customPackage 選択 後 に preview API で service を pre-select し
  // .a-color-price 要素 に ¥XXX を 表示 する。 これ を 待つ。
  // (旧 shipping-service-selector-row:not(.disabled) は 常時 disabled = 手動候補 だった)
  async function waitForServiceReady(row, maxMs = 25000) {
    const start = Date.now();
    while (Date.now() - start < maxMs) {
      await sleep(200);
      const priceEls = row.querySelectorAll('.a-color-price');
      for (const el of priceEls) {
        const m = (el.innerText || '').match(/[¥￥]\s?([\d,]+(?:\.\d+)?)/);
        if (m) {
          return { ok: true, cost: m[1].replace(/,/g, '').split('.')[0] };
        }
      }
    }
    return { ok: false };
  }

  async function selectShippingService(row, sizeName) {
    // ネコポス → 「ネコポス」 text を 含む enabled service row
    // 60/80/100/120 サイズ → 一番 安い enabled service を 選ぶ (Amazon が 自動 で 最安 提案)
    const targetKeyword = sizeName === 'ネコポス' ? 'ネコポス' : null;
    const rows = Array.from(row.querySelectorAll('tr.shipping-service-selector-row:not(.disabled)'));
    let selected = null;
    if (targetKeyword) {
      selected = rows.find(r => (r.innerText || '').includes(targetKeyword) && !r.innerText.includes('ファーマシー'));
    }
    if (!selected) {
      // fallback: 一番 上 の enabled row
      selected = rows[0];
    }
    if (!selected) return { ok: false, reason: '選択 可能 な service なし' };
    const radio = selected.querySelector('input[type="radio"]');
    if (!radio) return { ok: false, reason: 'radio button 見つからず' };
    radio.click();
    // 送料 額 抽出
    const costMatch = (selected.innerText || '').match(/[¥￥]\s?([\d,]+)/);
    const cost = costMatch ? costMatch[1].replace(/,/g, '') : '';
    return { ok: true, cost };
  }

  async function runBulkAutoFill() {
    log('bulk auto-fill start (v1.0 batch flow)');
    // Amazon page render 待ち (customPackage select が 出現 する まで)
    for (let i = 0; i < 30; i++) {
      const anySel = document.querySelector('select[name^="customPackage-"]');
      if (anySel) { log(`customPackage select 出現 (${i}秒後)`); break; }
      await sleep(1000);
    }
    await sleep(3000); // options populate まで の 余分 wait
    const rows = findOrderRows();
    log(`bulk order rows: ${rows.length}`);
    if (rows.length === 0) return { ok: false, error: 'order row 検出 ゼロ' };

    // ═══ Phase 1: 全 row 一気 に scan → classify (prompt しない) ═══
    log('Phase 1: scan');
    const items = [];
    for (const { orderId, row } of rows) {
      const sku = extractSectionSku(row);
      const product = extractSectionProduct(row);
      const imgUrl = extractSectionImg(row);
      const cached = await getOrderInfo(orderId);
      const buyer = cached?.buyer || '';

      // customPackage preset check
      let cpSelect = row.querySelector('select[name^="customPackage-"]');
      let savedOptions = cpSelect ? Array.from(cpSelect.options).filter(o => o.value !== '0' && o.value !== '') : [];
      // retry (max 3秒) for late populate
      for (let r = 0; r < 3 && savedOptions.length === 0 && cpSelect; r++) {
        await sleep(1000);
        savedOptions = Array.from(cpSelect.options).filter(o => o.value !== '0' && o.value !== '');
      }

      const existingL = parseFloat(row.querySelector('input[name="dimension.length"]')?.value || '0');
      const existingRadio = row.querySelector('tr.shipping-service-selector-row input[type="radio"]:checked');

      let type, extra = {};
      if (savedOptions.length > 0) {
        type = 'preset'; extra.preset = savedOptions[0]; extra.cpSelect = cpSelect;
      } else if (existingL > 0 || existingRadio) {
        type = 'existing'; extra.existingRadio = existingRadio;
      } else {
        const savedSize = await getSkuSize(sku);
        if (savedSize) { type = 'sku_saved'; extra.sizeName = savedSize; }
        else { type = 'need_prompt'; }
      }
      items.push({ orderId, row, sku, product, buyer, imgUrl, type, ...extra });
    }
    // scan 結果 log
    const scanCount = items.reduce((a,i)=>{ a[i.type] = (a[i.type]||0)+1; return a; }, {});
    log('scan 結果:', JSON.stringify(scanCount));

    // ═══ Phase 2: need_prompt を SKU で dedup → batch modal で 一度 に 聞く ═══
    const promptItems = items.filter(i => i.type === 'need_prompt');
    const skuChoices = {};
    if (promptItems.length > 0) {
      const skuMap = new Map();
      promptItems.forEach(i => {
        if (!skuMap.has(i.sku)) {
          skuMap.set(i.sku, { sku: i.sku, product: i.product, imgUrl: i.imgUrl, orderCount: 0 });
        }
        skuMap.get(i.sku).orderCount++;
      });
      const uniqueSkus = Array.from(skuMap.values());
      log(`batch prompt: ${uniqueSkus.length} SKU (${promptItems.length} 件 の 注文)`);
      const chosen = await showBatchSizePrompt(uniqueSkus);
      Object.assign(skuChoices, chosen);
      // storage 保存
      for (const [sku, size] of Object.entries(chosen)) {
        if (size) await saveSkuSize(sku, size);
      }
    }

    // ═══ Phase 3a: 全 row に 対して 値 set (小 stagger 100ms で 並列 突入 抑制) ═══
    log('Phase 3a: 全 row 値 set (native setter で React state 更新、 stagger 100ms)');
    for (const item of items) {
      const { row, type } = item;
      if (type === 'preset') {
        setSelectValueNative(item.cpSelect, item.preset.value);
      } else if (type === 'sku_saved' || type === 'need_prompt') {
        const sizeName = type === 'sku_saved' ? item.sizeName : skuChoices[item.sku];
        if (!sizeName) continue;
        const preset = SIZE_PRESETS[sizeName];
        fillOrderDimensions(row, preset);
        item._sizeName = sizeName;
      }
      // existing は 触ら ず
      await sleep(100); // 100ms stagger で Amazon の 並列 処理 過負荷 回避
    }
    log('Phase 3a 完了、 Amazon の 初期 計算 2秒 待ち');
    await sleep(2000);

    // ═══ Phase 3b: 全 row の Amazon pre-selected service (cost 表示) を 並列 で 待つ ═══
    // v1.0.5: shipping-service-selector-row は 常時 disabled (手動候補)、
    // Amazon が preview API で pre-select した service の cost 表示 (.a-color-price ¥XXX) を 検知
    log('Phase 3b: cost 表示 待ち (並列、 max 30秒 per row)');
    const fillResults = await Promise.all(items.map(async (item) => {
      const { orderId, row, sku, product, buyer, imgUrl, type } = item;
      try {
        let sizeLabel;
        if (type === 'preset') sizeLabel = item.preset.text.replace(/カスタムパッケージ\s*\(?/, '').replace(/\)?$/, '');
        else if (type === 'existing') sizeLabel = '既入力';
        else sizeLabel = item._sizeName;
        if (!sizeLabel && type !== 'existing') return { orderId, ok: false, reason: `SKU ${sku} スキップ (size 未選)` };

        // Amazon の cost 表示 を 待つ (30秒 max)
        const ready = await waitForServiceReady(row, 30000);
        if (!ready.ok) return { orderId, ok: false, reason: 'Amazon service pre-select されず (30秒 待機 超)' };

        return { orderId, product, sku, size: sizeLabel, cost: ready.cost, buyer, imgUrl, ok: true };
      } catch (e) {
        return { orderId, ok: false, reason: 'exception: ' + e.message };
      }
    }));

    const summary = { orders: [], errors: [], total: 0 };
    for (const r of fillResults) {
      if (r.ok) {
        summary.orders.push(r);
        summary.total += parseInt(r.cost || '0', 10);
      } else {
        summary.errors.push({ orderId: r.orderId, reason: r.reason });
      }
    }
    // 古い loop の 後続 コード は skip する ため、 早期 return 用 に この後 の 旧 コード へ jump しない
    log(`fill 完了: ${summary.orders.length} 件 成功、 ${summary.errors.length} 件 失敗`);
    const go = await showConfirmModal(summary);
    if (!go) return { ok: false, error: 'owner キャンセル' };
    const submitInput = document.querySelector('#bulk-buy-shipping-button input[type="submit"]');
    if (!submitInput) return { ok: false, error: 'submit button 見つからず' };
    for (let i = 0; i < 10 && submitInput.disabled; i++) await sleep(500);
    if (submitInput.disabled) return { ok: false, error: 'submit button 有効化 されず' };
    log('submit click');
    submitInput.click();
    monitorPostSubmit(summary.orders.map(o => o.orderId));
    return { ok: true, orderCount: summary.orders.length, total: summary.total, scanCount };
  }

  // ═══ post-submit: PDF DL + 印刷 monitor ══════════════════
  async function monitorPostSubmit(orderIds) {
    log('post-submit monitor 開始');
    const startUrl = location.href;
    const maxWaitMs = 60000; // 60秒
    const startTime = Date.now();
    let pdfLinks = [];

    while (Date.now() - startTime < maxWaitMs) {
      await sleep(2000);
      // 候補 pattern:
      // 1. URL が /purchases/ や /shipping-label/ に 遷移
      // 2. DOM に PDF link (.pdf を href に 含む) が 出現
      // 3. 「配送 ラベル の 印刷」「PDF ダウンロード」 系 button
      const links = Array.from(document.querySelectorAll('a[href*=".pdf"], a[href*="/shipping-label/"], a[href*="/print-label/"], a[href*="/get-label/"]'))
        .map(a => a.href).filter(Boolean);
      const printBtns = Array.from(document.querySelectorAll('button, input, [role="button"]'))
        .filter(el => /印刷|PDF|ダウンロード|Print|Download|Label/i.test((el.innerText || el.value || '') + ' ' + (el.getAttribute('aria-label') || '')));

      log(`monitor tick: url=${location.href.slice(-40)}, pdf links=${links.length}, print btns=${printBtns.length}`);

      if (links.length > 0) {
        pdfLinks = [...new Set(links)];
        break;
      }

      // URL 遷移 検知
      if (location.href !== startUrl && !location.href.includes('/bulk-buy-shipping/')) {
        log(`URL 遷移 検知: ${location.href}`);
        // 遷移 先 で再度 link 探索
        await sleep(3000);
        const links2 = Array.from(document.querySelectorAll('a[href*=".pdf"], a[href*="label"], a[href*="shipping"]'))
          .map(a => a.href).filter(h => /\.pdf|label|shipping/i.test(h) && !h.includes('/bulk-buy-shipping/'));
        if (links2.length > 0) { pdfLinks = [...new Set(links2)]; break; }
      }
    }

    if (pdfLinks.length === 0) {
      log('❌ PDF link 検出 タイムアウト → owner に Amazon UI 手動 印刷 依頼');
      showPostSubmitMessage(false, orderIds.length, pdfLinks);
      return;
    }

    log(`PDF ${pdfLinks.length}件 検出 → 全部 open`);
    // 全 PDF を 新 tab で 開く (chrome 内蔵 PDF viewer で 表示)
    pdfLinks.forEach(url => {
      const w = window.open(url, '_blank');
      // PDF viewer 側 で auto-print は browser 依存
    });
    showPostSubmitMessage(true, orderIds.length, pdfLinks);
  }

  function showPostSubmitMessage(ok, orderCount, pdfLinks) {
    const box = document.createElement('div');
    box.style.cssText = `position:fixed;bottom:20px;right:20px;background:${ok ? '#060' : '#B00'};color:#fff;padding:14px 18px;border-radius:8px;z-index:2147483647;box-shadow:0 4px 20px rgba(0,0,0,0.3);font-family:sans-serif;font-size:13px;max-width:400px;`;
    if (ok) {
      box.innerHTML = `
        <strong>✓ 購入 完了 + PDF ${pdfLinks.length}件 open 済</strong><br>
        <span style="font-size:11px;">各 tab で ⌘P で 印刷、 or Amazon の 「一括 印刷」 button 使用</span>
      `;
    } else {
      box.innerHTML = `
        <strong>⚠ 購入 送信 済 だが PDF link 検出 タイムアウト</strong><br>
        <span style="font-size:11px;">Amazon UI で 「配送 ラベル 印刷」 button を 手動 で 押して、 全 ${orderCount}件 PDF を DL してください</span>
      `;
    }
    document.body.appendChild(box);
    setTimeout(() => box.remove(), 15000);
  }

  // ═══ キャンセル 依頼 一括 承認 (best effort、 v0.6) ══════
  async function runBulkCancelApprove() {
    log('cancel approve start');
    const rows = document.querySelectorAll('table#orders-table tbody tr');
    const targets = [];
    rows.forEach(row => {
      const text = row.innerText || '';
      if (/キャンセルをリクエスト|注文のキャンセル/.test(text)) {
        const orderIdEl = row.querySelector('.cell-body-title a[href*="/orders-v3/order/"]');
        const cancelBtn = Array.from(row.querySelectorAll('input[type="submit"], a')).find(el => {
          const t = (el.value || el.innerText || '').trim();
          return t === '注文キャンセル' || t.includes('注文キャンセル');
        });
        if (orderIdEl && cancelBtn) {
          targets.push({ orderId: orderIdEl.innerText.trim(), cancelBtn, href: cancelBtn.href || null });
        }
      }
    });
    log(`cancel target: ${targets.length}`);
    if (targets.length === 0) return { ok: false, error: 'キャンセル 依頼 order なし' };

    // 一括 承認 確認 modal
    const proceed = await new Promise(resolve => {
      const overlay = document.createElement('div');
      overlay.style.cssText = `position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:2147483647;display:flex;align-items:center;justify-content:center;font-family:sans-serif;`;
      overlay.innerHTML = `
        <div style="background:#fff;padding:24px;border-radius:10px;max-width:520px;width:90%;">
          <h2 style="margin:0 0 12px;font-size:16px;">キャンセル 依頼 一括 承認</h2>
          <p style="font-size:13px;line-height:1.6;">
            ${targets.length}件 の キャンセル 依頼 を 順次 承認 します (Amazon の 個別 注文 詳細 page に 遷移 → 「注文キャンセル」 push → 理由 「購入者要請」 → 送信)。
            <br><br>
            <strong>注意</strong>: Amazon UI の 挙動 次第 で 手動 fallback が 必要 な case あり。 詳細 は 各 order の 遷移 先 で 確認。
          </p>
          <ul style="font-size:12px;font-family:monospace;color:#666;max-height:200px;overflow:auto;">
            ${targets.map(t => `<li>#${escapeHtml(t.orderId)}</li>`).join('')}
          </ul>
          <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:16px;">
            <button id="jc-cancel" style="padding:10px 16px;border:1px solid #ccc;background:#fff;border-radius:6px;cursor:pointer;">やめる</button>
            <button id="jc-ok" style="padding:10px 20px;border:0;background:#D00;color:#fff;font-weight:600;border-radius:6px;cursor:pointer;">承認 開始</button>
          </div>
        </div>
      `;
      document.body.appendChild(overlay);
      overlay.querySelector('#jc-cancel').onclick = () => { document.body.removeChild(overlay); resolve(false); };
      overlay.querySelector('#jc-ok').onclick = () => { document.body.removeChild(overlay); resolve(true); };
    });
    if (!proceed) return { ok: false, error: 'owner キャンセル' };

    // v0.6: 各 order の 詳細 page で 手動 実行 を 促す (直 fully 自動 は cancel dialog 構造 未 inspect の ため 保留)
    const first = targets[0];
    if (first.href) {
      log(`最初 の order へ 遷移: ${first.href}`);
      // remaining は storage に 保存 (順次 遷移 に 使う 予定、 v0.7 で 実装)
      window.open(first.href, '_blank');
    } else {
      first.cancelBtn.click();
    }
    return { ok: true, targetCount: targets.length, note: '最初 の 1件 を 新 tab で 開いた。 owner が cancel modal 承認 → 次 を 手動 or 拡張 v0.7 で 一括 化' };
  }

  // ═══ 外部 API (popup から executeScript で 呼ぶ) ═══════════
  window.__jobsPickingRun = runPickingList;
  window.__jobsGoBulk = goToBulkBuyShipping;
  window.__jobsBulkAutoFill = runBulkAutoFill;
  window.__jobsCombinedBulk = runCombinedBulk;
  window.__jobsBulkCancelApprove = runBulkCancelApprove;

  // bulk page 遷移 直後 の auto-fill 発動 (統合 flow の 継続)
  async function autoTriggerBulkFillIfFlagged() {
    if (!location.pathname.includes('/bulk-buy-shipping/')) return;
    if (typeof chrome === 'undefined' || !chrome.storage?.local) return;
    chrome.storage.local.get('jobs_in_bulk_flow', async (data) => {
      const flag = data.jobs_in_bulk_flow;
      if (!flag) return;
      // 5分 以内 の flag のみ 有効
      if (Date.now() - flag.started > 5 * 60 * 1000) {
        chrome.storage.local.remove('jobs_in_bulk_flow');
        return;
      }
      log('bulk page 遷移 検知 + flag あり → auto-fill 起動');
      chrome.storage.local.remove('jobs_in_bulk_flow');
      // page render 待ち
      await sleep(5000);
      runBulkAutoFill().catch(e => log('auto bulk fill err:', e.message));
    });
  }
  setTimeout(autoTriggerBulkFillIfFlagged, 1500);

  // ═══ main world bridge (verify / debug 用) ════════════════
  // content script は isolated world に 走る の で、 page.evaluate (main world) から
  // window.__jobsBulkAutoFill を 見え ない。 CustomEvent で bridge。
  window.addEventListener('__jobs_call', async (ev) => {
    const { fn, id } = ev.detail || {};
    let result;
    try {
      if (typeof window[fn] !== 'function') throw new Error(`${fn} not a function`);
      result = { ok: true, data: await window[fn]() };
    } catch (e) {
      result = { ok: false, error: e.message };
    }
    window.dispatchEvent(new CustomEvent('__jobs_result', { detail: { id, result } }));
  });

  // main world 側 から 呼ぶ helper (page.evaluate で inject して 使う)
  const bridgeInjector = `
    window.__jobsBridge = function(fnName) {
      return new Promise((resolve) => {
        const id = Math.random().toString(36).slice(2);
        const handler = (ev) => {
          if (ev.detail?.id === id) {
            window.removeEventListener('__jobs_result', handler);
            resolve(ev.detail.result);
          }
        };
        window.addEventListener('__jobs_result', handler);
        window.dispatchEvent(new CustomEvent('__jobs_call', { detail: { fn: fnName, id } }));
      });
    };
  `;
  const s = document.createElement('script');
  s.textContent = bridgeInjector;
  (document.head || document.documentElement).appendChild(s);
  s.remove();

  const path = location.pathname;
  window.__jobsPageMode = path.includes('/bulk-buy-shipping/') ? 'bulk'
                        : path.includes('/orders-v3/') ? 'unshipped'
                        : 'other';

  log(`v1.0.5 loaded, mode = ${window.__jobsPageMode}, bridge ready`);
})();
