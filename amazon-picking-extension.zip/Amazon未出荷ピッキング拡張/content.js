/**
 * Jobs ピッキング + 伝票 自動 拡張 (v0.4)
 *
 * page 判定 で 2 mode に 分岐:
 *   A. 未出荷 一覧 (/orders-v3/ref=xx_myo_favb_xx?shipByDate=all)
 *      → 商品別 ピッキングリスト A4 印刷 (v0.3 継承 + 写真付)
 *      → popup に 「続けて 伝票 購入」 button で bulk-buy-shipping へ 遷移
 *   B. bulk-buy-shipping (/orders-v3/bulk-buy-shipping/ORDER1;ORDER2;...)
 *      → 各 order の SKU 見て chrome.storage の size preset 適用
 *      → 未登録 SKU は modal で 「この 商品 サイズ 何?」 popup
 *      → 全 order fill 後 summary → owner が 「確認 実行」 → Amazon submit
 *      → PDF DL + 印刷 は Amazon 側 が 自動 提供 する
 *
 * size preset (owner 明示 2026-08-27):
 *   ネコポス: 23 × 12 × 2 cm, 100 g
 *   60サイズ:  20 × 20 × 20 cm, 500 g
 *   80サイズ:  25 × 25 × 25 cm, 1500 g
 *   100サイズ: 30 × 30 × 30 cm, 3000 g
 *   120サイズ: 35 × 35 × 30 cm, 5000 g
 */

(function () {
  'use strict';

  document.documentElement.setAttribute('data-jobs-picking-loaded', 'v0.4');

  const sleep = (ms) => new Promise(r => setTimeout(r, ms));
  const log = (...a) => console.log('[Jobs Ext]', ...a);

  // ═══ size preset ═══════════════════════════════════════════
  const SIZE_PRESETS = {
    'ネコポス':   { length: 23, width: 12, height: 2,  weight_g: 100  },
    '60サイズ':   { length: 20, width: 20, height: 20, weight_g: 500  },
    '80サイズ':   { length: 25, width: 25, height: 25, weight_g: 1500 },
    '100サイズ':  { length: 30, width: 30, height: 30, weight_g: 3000 },
    '120サイズ':  { length: 35, width: 35, height: 30, weight_g: 5000 },
  };

  // ═══ storage helpers (chrome.storage.local) ═══════════════
  async function getSkuSize(sku) {
    if (!sku) return null;
    return new Promise(resolve => {
      chrome.storage.local.get('sku_sizes', (data) => {
        resolve(data.sku_sizes?.[sku] || null);
      });
    });
  }
  async function saveSkuSize(sku, sizeName) {
    return new Promise(resolve => {
      chrome.storage.local.get('sku_sizes', (data) => {
        const sizes = data.sku_sizes || {};
        sizes[sku] = sizeName;
        chrome.storage.local.set({ sku_sizes: sizes }, resolve);
      });
    });
  }

  // ═══ size prompt modal ════════════════════════════════════
  function showSizePrompt(productName, sku, imgUrl) {
    return new Promise(resolve => {
      const overlay = document.createElement('div');
      overlay.id = 'jobs-size-modal';
      overlay.style.cssText = `position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.6);z-index:2147483647;display:flex;align-items:center;justify-content:center;font-family:-apple-system,"Hiragino Kaku Gothic ProN",sans-serif;`;
      const opts = Object.entries(SIZE_PRESETS).map(([name, p], i) => `
        <label style="display:block;padding:10px 12px;border:1px solid #ddd;border-radius:6px;margin-bottom:6px;cursor:pointer;font-size:14px;">
          <input type="radio" name="jobs-size" value="${name}" ${i === 0 ? 'checked' : ''} style="margin-right:8px;">
          <strong>${name}</strong>
          <span style="color:#666;font-size:12px;margin-left:8px;">${p.length}×${p.width}×${p.height}cm / ${p.weight_g}g</span>
        </label>
      `).join('');
      overlay.innerHTML = `
        <div style="background:#fff;padding:24px;border-radius:10px;max-width:560px;width:90%;box-shadow:0 10px 40px rgba(0,0,0,0.3);">
          <h2 style="margin:0 0 16px;font-size:16px;color:#232F3E;">この 商品 の 配送 サイズ は?</h2>
          <div style="display:flex;gap:12px;padding:10px;background:#F5F5F5;border-radius:6px;margin-bottom:16px;align-items:center;">
            ${imgUrl ? `<img src="${imgUrl}" style="width:60px;height:60px;object-fit:contain;background:#fff;border:1px solid #ccc;">` : ''}
            <div style="flex:1;min-width:0;">
              <div style="font-weight:600;font-size:13px;line-height:1.4;">${escapeHtml(productName)}</div>
              <div style="font-family:monospace;font-size:11px;color:#666;margin-top:4px;">SKU: ${escapeHtml(sku)}</div>
            </div>
          </div>
          <form id="jobs-size-form" style="margin:0 0 16px;">
            ${opts}
          </form>
          <div style="display:flex;gap:8px;justify-content:flex-end;">
            <button id="jobs-size-skip" style="padding:10px 16px;border:1px solid #ccc;background:#fff;border-radius:6px;cursor:pointer;">スキップ (この 商品 は 手動)</button>
            <button id="jobs-size-ok" style="padding:10px 20px;border:0;background:#FF9900;color:#000;font-weight:600;border-radius:6px;cursor:pointer;">OK</button>
          </div>
          <div style="font-size:11px;color:#888;margin-top:12px;text-align:center;">選択 は 保存 されて、 次回 同 SKU では 聞かれ ません。</div>
        </div>
      `;
      document.body.appendChild(overlay);

      overlay.querySelector('#jobs-size-ok').onclick = () => {
        const val = overlay.querySelector('input[name="jobs-size"]:checked')?.value;
        document.body.removeChild(overlay);
        resolve(val || null);
      };
      overlay.querySelector('#jobs-size-skip').onclick = () => {
        document.body.removeChild(overlay);
        resolve(null);
      };
    });
  }

  // ═══ confirm summary modal ═══════════════════════════════
  function showConfirmModal(summary) {
    return new Promise(resolve => {
      const overlay = document.createElement('div');
      overlay.style.cssText = `position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:2147483647;display:flex;align-items:center;justify-content:center;font-family:-apple-system,"Hiragino Kaku Gothic ProN",sans-serif;`;
      const rows = summary.orders.map(o => `
        <tr>
          <td style="padding:6px 8px;border-bottom:1px solid #eee;font-size:11px;font-family:monospace;">${escapeHtml(o.orderId)}</td>
          <td style="padding:6px 8px;border-bottom:1px solid #eee;font-size:12px;">${escapeHtml(o.product.slice(0, 30))}</td>
          <td style="padding:6px 8px;border-bottom:1px solid #eee;font-size:12px;">${o.size || '—'}</td>
          <td style="padding:6px 8px;border-bottom:1px solid #eee;font-size:12px;text-align:right;">¥${o.cost || '—'}</td>
        </tr>
      `).join('');
      overlay.innerHTML = `
        <div style="background:#fff;padding:24px;border-radius:10px;max-width:800px;width:90%;max-height:80vh;overflow:auto;box-shadow:0 10px 40px rgba(0,0,0,0.3);">
          <h2 style="margin:0 0 12px;font-size:16px;color:#232F3E;">配送 ラベル 一括 購入 確認</h2>
          <div style="background:#FFF3E0;border-left:4px solid #FF9900;padding:10px 14px;margin-bottom:16px;font-size:13px;">
            <strong>${summary.orders.length}件</strong> の 配送 ラベル を 購入 します。 送料 は Amazon 出品 account から 即時 引き落とし。 実行 後 は 各 label を Amazon UI から PDF DL 可能。
          </div>
          <table style="width:100%;border-collapse:collapse;margin-bottom:16px;">
            <thead>
              <tr style="background:#F5F5F5;">
                <th style="padding:8px;text-align:left;font-size:12px;border-bottom:2px solid #ccc;">注文 ID</th>
                <th style="padding:8px;text-align:left;font-size:12px;border-bottom:2px solid #ccc;">商品</th>
                <th style="padding:8px;text-align:left;font-size:12px;border-bottom:2px solid #ccc;">サイズ</th>
                <th style="padding:8px;text-align:right;font-size:12px;border-bottom:2px solid #ccc;">送料</th>
              </tr>
            </thead>
            <tbody>${rows}</tbody>
            <tfoot>
              <tr style="background:#FFF3E0;font-weight:700;">
                <td colspan="3" style="padding:10px 8px;text-align:right;">合計:</td>
                <td style="padding:10px 8px;text-align:right;">¥${summary.total}</td>
              </tr>
            </tfoot>
          </table>
          ${summary.errors.length ? `
            <div style="background:#FEE;border-left:4px solid #D00;padding:10px 14px;margin-bottom:16px;font-size:12px;">
              <strong>⚠ ${summary.errors.length}件 fill 失敗</strong>: Amazon UI で 手動 確認 要
              <ul style="margin:6px 0 0;padding-left:20px;">
                ${summary.errors.map(e => `<li>${escapeHtml(e.orderId)} — ${escapeHtml(e.reason)}</li>`).join('')}
              </ul>
            </div>
          ` : ''}
          <div style="display:flex;gap:8px;justify-content:flex-end;">
            <button id="jobs-cancel" style="padding:10px 16px;border:1px solid #ccc;background:#fff;border-radius:6px;cursor:pointer;">キャンセル</button>
            <button id="jobs-confirm" style="padding:10px 20px;border:0;background:#D00;color:#fff;font-weight:600;border-radius:6px;cursor:pointer;">${summary.errors.length ? '成功分 のみ' : '全件'} 実行 (¥${summary.total} 課金)</button>
          </div>
        </div>
      `;
      document.body.appendChild(overlay);
      overlay.querySelector('#jobs-cancel').onclick = () => { document.body.removeChild(overlay); resolve(false); };
      overlay.querySelector('#jobs-confirm').onclick = () => { document.body.removeChild(overlay); resolve(true); };
    });
  }

  function escapeHtml(s) {
    return String(s || '').replace(/[&<>"']/g, c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));
  }

  // ═══ 未出荷 一覧 page: picking list ═══════════════════════
  function parseUnshippedRow(row) {
    const text = (row.innerText || '').replace(/\s+/g, ' ').trim();
    const buyer = row.querySelector('[data-test-id="buyer-name-with-link"]')?.innerText?.trim() || '';
    const orderIdEl = row.querySelector('.cell-body-title a[href*="/orders-v3/order/"]');
    const orderId = orderIdEl?.innerText?.trim() || text.match(/\d{3}-\d{7}-\d{7}/)?.[0] || '';
    const productCell = row.querySelector('.myo-list-orders-product-name-cell');
    if (!productCell) return null;
    const cellText = productCell.innerText || '';
    const product = productCell.querySelector('a[href*="/gp/product/"] div')?.innerText?.trim() ||
                    cellText.split('\n')[0]?.trim() || '';
    let imgUrl = row.querySelector('.myo-list-orders-product-image-cell img')?.src || '';
    if (imgUrl) imgUrl = imgUrl.replace(/_SR\d+,\d+_/, '_SR300,300_').replace(/_SL\d+_/, '_SL300_');
    const asin = cellText.match(/ASIN[:：]\s*([A-Z0-9]{10})/)?.[1] || '';
    const sku = cellText.match(/SKU[:：]\s*(\S+)/)?.[1] || '';
    const qty = parseInt(cellText.match(/数量[:：]\s*(\d+)/)?.[1] || '1', 10);
    if (!product || !buyer) return null;
    return { buyer, product, qty, orderId, asin, sku, imgUrl };
  }

  async function setMaxPageSize() {
    const sel = document.querySelector('select#myo-table-results-per-page');
    if (!sel || sel.value === '100') return false;
    sel.value = '100';
    sel.dispatchEvent(new Event('change', { bubbles: true }));
    await sleep(3000);
    return true;
  }
  async function clickNextPage() {
    const nextLi = document.querySelector('ul.a-pagination li.a-last');
    if (!nextLi || nextLi.classList.contains('a-disabled')) return false;
    const link = nextLi.querySelector('a');
    if (!link) return false;
    link.click();
    return true;
  }
  function scrapePage() {
    const rows = document.querySelectorAll('table#orders-table tbody tr');
    const items = [];
    rows.forEach(row => { const p = parseUnshippedRow(row); if (p) items.push(p); });
    return items;
  }
  async function scrapeAllUnshipped(maxPages = 30) {
    if (await setMaxPageSize()) await sleep(2000);
    let all = [];
    for (let i = 0; i < maxPages; i++) {
      await sleep(500);
      all = all.concat(scrapePage());
      if (!(await clickNextPage())) break;
      await sleep(2500);
    }
    return all;
  }

  function groupAndSort(items) {
    const groups = new Map();
    items.forEach(it => {
      if (!groups.has(it.product)) groups.set(it.product, []);
      groups.get(it.product).push(it);
    });
    for (const arr of groups.values()) {
      arr.sort((a, b) => (b.qty - a.qty) || a.buyer.localeCompare(b.buyer, 'ja'));
    }
    return Array.from(groups.entries()).map(([product, arr]) => ({
      product, total: arr.reduce((s, x) => s + x.qty, 0),
      asin: arr[0]?.asin || '', sku: arr[0]?.sku || '', imgUrl: arr[0]?.imgUrl || '',
      buyers: arr,
    })).sort((a, b) => b.total - a.total);
  }

  function buildPickingHTML(groups) {
    const t = new Date();
    const dateStr = `${t.getFullYear()}-${String(t.getMonth()+1).padStart(2,'0')}-${String(t.getDate()).padStart(2,'0')}`;
    const weekday = ['日','月','火','水','木','金','土'][t.getDay()];
    const totalItems = groups.reduce((s,g) => s+g.total, 0);
    const totalOrders = groups.reduce((s,g) => s+g.buyers.length, 0);
    const groupsHTML = groups.map(g => `
      <section class="group">
        <div class="group-head">
          ${g.imgUrl ? `<img class="thumb" src="${escapeHtml(g.imgUrl)}" alt="" crossorigin="anonymous">` : '<div class="thumb thumb-blank"></div>'}
          <div class="group-title">
            <h2><span class="pname">${escapeHtml(g.product)}</span><span class="qty">×${g.total}個</span></h2>
            ${g.asin || g.sku ? `<div class="meta">${g.asin ? `ASIN ${escapeHtml(g.asin)}` : ''}${g.asin && g.sku ? '  /  ' : ''}${g.sku ? `SKU ${escapeHtml(g.sku)}` : ''}</div>` : ''}
          </div>
        </div>
        <ol>${g.buyers.map((b,i)=>`<li><span class="num">${i+1}.</span><span class="buyer">${escapeHtml(b.buyer)} 様</span><span class="q">×${b.qty}</span><span class="oid">${escapeHtml(b.orderId)}</span></li>`).join('')}</ol>
      </section>
    `).join('');
    return `<!DOCTYPE html><html lang="ja"><head><meta charset="UTF-8"><title>ピッキングリスト ${dateStr}</title>
<style>
  @page { size: A4 portrait; margin: 12mm; }
  *{box-sizing:border-box;} body{font-family:-apple-system,"Hiragino Kaku Gothic ProN","Yu Gothic",sans-serif;color:#111;margin:0;padding:0;font-size:11pt;line-height:1.5;}
  header{border-bottom:2px solid #000;padding:0 0 6px;margin-bottom:12px;display:flex;justify-content:space-between;align-items:baseline;}
  h1{font-size:14pt;margin:0;font-weight:700;} .meta-header{font-size:10pt;color:#444;}
  .group{break-inside:avoid;page-break-inside:avoid;margin-bottom:14px;border:1px solid #ddd;border-radius:4px;overflow:hidden;}
  .group-head{display:grid;grid-template-columns:64px 1fr;gap:10px;padding:6px 8px;background:#F5F5F5;border-bottom:1px solid #ddd;align-items:center;}
  .thumb{width:60px;height:60px;object-fit:contain;background:#fff;border:1px solid #ccc;} .thumb-blank{background:#EEE;border:1px dashed #ccc;}
  .group-title{min-width:0;} h2{font-size:12pt;margin:0;padding:0;background:transparent;border-left:0;display:flex;justify-content:space-between;align-items:baseline;font-weight:700;}
  h2 .pname{flex:1;padding-right:12px;word-break:break-word;} h2 .qty{font-weight:700;white-space:nowrap;}
  .meta{font-size:9pt;color:#666;padding:2px 0 0;font-family:"SF Mono",Menlo,monospace;}
  ol{margin:0;padding:0;list-style:none;} li{padding:4px 10px;border-bottom:1px dotted #ccc;display:grid;grid-template-columns:24px 1fr 60px 200px;gap:8px;align-items:baseline;font-variant-numeric:tabular-nums;}
  li:last-child{border-bottom:0;} .num{color:#999;font-size:10pt;text-align:right;} .buyer{font-weight:500;} .q{text-align:right;font-weight:700;} .oid{font-family:"SF Mono",Menlo,monospace;font-size:9pt;color:#666;}
  footer{margin-top:16px;padding-top:6px;border-top:1px solid #999;text-align:right;font-size:10pt;color:#666;}
  .print-btn{position:fixed;top:12px;right:12px;padding:10px 16px;background:#FF9900;color:#000;border:0;border-radius:6px;cursor:pointer;font-weight:600;box-shadow:0 2px 6px rgba(0,0,0,0.2);}
  @media print{.print-btn{display:none!important;}}
</style></head><body>
<button class="print-btn" onclick="window.print()">印刷 (⌘P)</button>
<header><h1>ピッキングリスト</h1><div class="meta-header">${dateStr} (${weekday}) — 未出荷 ${totalOrders}件 / 合計 ${totalItems}個</div></header>
${groupsHTML}
<footer>合計 ${totalItems}個 / ${totalOrders}件 — Jobs ピッキング拡張 v0.4</footer>
<script>setTimeout(() => window.print(), 500);</script>
</body></html>`;
  }

  async function runPickingList() {
    log('picking list start');
    const items = await scrapeAllUnshipped();
    if (items.length === 0) return { ok: false, error: '未出荷 row 検出 ゼロ' };
    const groups = groupAndSort(items);
    const html = buildPickingHTML(groups);
    const blob = new Blob([html], { type: 'text/html' });
    window.open(URL.createObjectURL(blob), '_blank');
    return { ok: true, itemCount: groups.length, orderCount: items.length };
  }

  // ═══ 未出荷 → bulk-buy-shipping 遷移 ═══════════════════════
  async function goToBulkBuyShipping() {
    log('bulk-buy-shipping 遷移 開始');
    // 全 checkbox 選択
    const header = document.querySelector('table#orders-table thead input[type="checkbox"]');
    if (header) {
      header.click();
      await sleep(1000);
    }
    const checkedCount = document.querySelectorAll('table#orders-table tbody input[type="checkbox"]:checked').length;
    log(`checked: ${checkedCount}`);
    if (checkedCount === 0) {
      // fallback: 個別 click
      document.querySelectorAll('table#orders-table tbody input[type="checkbox"]').forEach(cb => { if (!cb.checked) cb.click(); });
      await sleep(1500);
    }
    // link 取得
    const bulkLink = document.querySelector('[data-test-id="ab-bulk-buy-shipping"] a[href*="bulk-buy-shipping"]');
    if (!bulkLink) return { ok: false, error: 'bulk-buy-shipping link 見つからず (checkbox 未選択?)' };
    log('bulk link:', bulkLink.href);
    location.href = bulkLink.href;
    return { ok: true };
  }

  // ═══ bulk-buy-shipping page: 自動 fill ═══════════════════
  function findOrderRows() {
    // 各 order は <tr> で 囲まれ、 中 に order id リンク + weight.kg/g + dimension.length/width/height を 持つ
    const rows = [];
    document.querySelectorAll('a[href*="/orders-v3/order/"][target="_blank"]').forEach(a => {
      const orderId = a.innerText.trim();
      if (!/^\d{3}-\d{7}-\d{7}$/.test(orderId)) return;
      // 一番 近い <tr> を 探す
      let tr = a.closest('tr');
      // 上位 tr が form field を 含まない case あり → 更に 上 の tr を 使う
      while (tr && !tr.querySelector('input[name="dimension.length"]') && !tr.querySelector('input[name="weight.g"]')) {
        tr = tr.parentElement?.closest('tr') || null;
      }
      if (tr) rows.push({ orderId, row: tr });
    });
    return rows;
  }

  function extractSectionSku(row) {
    const text = row.innerText || '';
    return text.match(/SKU[:\s]*([^\s\r\n]+)/)?.[1] || '';
  }
  function extractSectionProduct(row) {
    const text = row.innerText || '';
    // SKU の 直前 の 行 が 商品名
    const lines = text.split('\n').map(s => s.trim()).filter(Boolean);
    const skuIdx = lines.findIndex(l => /^SKU/.test(l));
    if (skuIdx > 0) return lines[skuIdx - 1];
    return lines[1] || '';
  }
  function extractSectionImg(row) {
    return row.querySelector('img')?.src || '';
  }

  function fillOrderDimensions(row, preset) {
    const setValue = (el, val) => {
      if (!el) return false;
      el.value = String(val);
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      return true;
    };
    const okL = setValue(row.querySelector('input[name="dimension.length"]'), preset.length);
    const okW = setValue(row.querySelector('input[name="dimension.width"]'), preset.width);
    const okH = setValue(row.querySelector('input[name="dimension.height"]'), preset.height);
    const okG = setValue(row.querySelector('input[name="weight.g"]'), preset.weight_g);
    // kg 0 で 明示 set (Amazon の validation で kg + g 分離 の 場合)
    const okKg = setValue(row.querySelector('input[name="weight.kg"]'), 0);
    return okL && okW && okH && okG;
  }

  async function waitForServiceRefresh(row) {
    // fill 後 に shipping-service-selector-row の enabled 状態 が 更新 されるまで 待つ
    for (let i = 0; i < 10; i++) {
      await sleep(500);
      const enabledRows = row.querySelectorAll('tr.shipping-service-selector-row:not(.disabled) input[type="radio"]');
      if (enabledRows.length > 0) return true;
    }
    return false;
  }

  async function selectShippingService(row, sizeName) {
    // ネコポス → 「ネコポス」 text を 含む enabled service row
    // 60/80/100/120 サイズ → 一番 安い enabled service を 選ぶ (Amazon が 自動 で 最安 提案)
    const targetKeyword = sizeName === 'ネコポス' ? 'ネコポス' : null;
    const rows = Array.from(row.querySelectorAll('tr.shipping-service-selector-row:not(.disabled)'));
    let selected = null;
    if (targetKeyword) {
      selected = rows.find(r => (r.innerText || '').includes(targetKeyword) && !r.innerText.includes('ファーマシー'));
    }
    if (!selected) {
      // fallback: 一番 上 の enabled row
      selected = rows[0];
    }
    if (!selected) return { ok: false, reason: '選択 可能 な service なし' };
    const radio = selected.querySelector('input[type="radio"]');
    if (!radio) return { ok: false, reason: 'radio button 見つからず' };
    radio.click();
    // 送料 額 抽出
    const costMatch = (selected.innerText || '').match(/[¥￥]\s?([\d,]+)/);
    const cost = costMatch ? costMatch[1].replace(/,/g, '') : '';
    return { ok: true, cost };
  }

  async function runBulkAutoFill() {
    log('bulk auto-fill start');
    // page render 待ち
    await sleep(3000);
    const rows = findOrderRows();
    log(`bulk order rows: ${rows.length}`);
    if (rows.length === 0) return { ok: false, error: 'order row 検出 ゼロ' };

    const summary = { orders: [], errors: [], total: 0 };

    for (const { orderId, row } of rows) {
      const sku = extractSectionSku(row);
      const product = extractSectionProduct(row);
      const imgUrl = extractSectionImg(row);

      // SKU size lookup
      let sizeName = await getSkuSize(sku);
      if (!sizeName) {
        log(`SKU 未登録: ${sku}, prompt 開く`);
        sizeName = await showSizePrompt(product, sku, imgUrl);
        if (!sizeName) {
          summary.errors.push({ orderId, reason: `SKU ${sku} owner スキップ` });
          continue;
        }
        await saveSkuSize(sku, sizeName);
      }
      log(`SKU ${sku} → ${sizeName}`);

      const preset = SIZE_PRESETS[sizeName];
      if (!fillOrderDimensions(row, preset)) {
        summary.errors.push({ orderId, reason: `dimension input 見つからず (${sizeName})` });
        continue;
      }

      // service 再計算 待ち
      const enabled = await waitForServiceRefresh(row);
      if (!enabled) {
        summary.errors.push({ orderId, reason: 'shipping service 選択 可能 な もの なし (寸法 と 発送先 が service 制約 に 合わない?)' });
        continue;
      }

      const svc = await selectShippingService(row, sizeName);
      if (!svc.ok) {
        summary.errors.push({ orderId, reason: svc.reason });
        continue;
      }

      summary.orders.push({ orderId, product, size: sizeName, cost: svc.cost });
      summary.total += parseInt(svc.cost || '0', 10);
    }

    log(`fill 完了: ${summary.orders.length} 件 成功、 ${summary.errors.length} 件 失敗`);

    // confirm gate
    const go = await showConfirmModal(summary);
    if (!go) return { ok: false, error: 'owner キャンセル' };

    // Amazon submit button click
    const submitInput = document.querySelector('#bulk-buy-shipping-button input[type="submit"]');
    if (!submitInput) return { ok: false, error: 'submit button 見つからず' };
    if (submitInput.disabled) {
      // enable を 待つ
      for (let i = 0; i < 10; i++) {
        await sleep(500);
        if (!submitInput.disabled) break;
      }
    }
    if (submitInput.disabled) return { ok: false, error: 'submit button 有効化 されず (fill 未完了?)' };

    log('submit click');
    submitInput.click();
    return { ok: true, orderCount: summary.orders.length, total: summary.total };
  }

  // ═══ 外部 API (popup から executeScript で 呼ぶ) ═══════════
  window.__jobsPickingRun = runPickingList;
  window.__jobsGoBulk = goToBulkBuyShipping;
  window.__jobsBulkAutoFill = runBulkAutoFill;

  // 現在 page 判定 して 自動 起動 する か 決める
  // bulk-buy-shipping page なら popup 通さ ず 自動 起動 (owner 明示 GO の 前提)
  const path = location.pathname;
  window.__jobsPageMode = path.includes('/bulk-buy-shipping/') ? 'bulk'
                        : path.includes('/orders-v3/') ? 'unshipped'
                        : 'other';

  log(`v0.4 loaded, mode = ${window.__jobsPageMode}`);
})();
