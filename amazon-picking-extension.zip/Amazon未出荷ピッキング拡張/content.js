/**
 * Jobs ピッキングリスト content script (v0.2)
 *
 * 実 DOM (2026-08-27 seller central 未出荷 page) 対応 版。
 * selector は inspect.mjs で 実測 した DOM 構造 に 基づく。
 *
 * URL pattern: /orders-v3/ref=xx_myo_favb_xx?shipByDate=all
 * table id: orders-table
 * row: table#orders-table tbody tr
 * buyer: [data-test-id="buyer-name-with-link"]
 * product cell: .myo-list-orders-product-name-cell
 * order id: .cell-body-title a[href*="/orders-v3/order/"]
 * pagination: ul.a-pagination li.a-last a
 * page size: select#myo-table-results-per-page
 */

(function () {
  'use strict';

  document.documentElement.setAttribute('data-jobs-picking-loaded', 'v0.2');

  const sleep = (ms) => new Promise(r => setTimeout(r, ms));
  const log = (...a) => console.log('[Jobs Picking]', ...a);

  // ─── 1 row を parse ─────────────────────────────────────
  function parseRow(row) {
    const text = (row.innerText || '').replace(/\s+/g, ' ').trim();

    // 買い手名
    const buyerEl = row.querySelector('[data-test-id="buyer-name-with-link"]');
    const buyer = buyerEl?.innerText?.trim() || '';

    // 注文ID
    const orderIdEl = row.querySelector('.cell-body-title a[href*="/orders-v3/order/"]');
    const orderId = orderIdEl?.innerText?.trim() ||
                    text.match(/\d{3}-\d{7}-\d{7}/)?.[0] || '';

    // 商品 cell (1 row に 複数 商品 が ある case は 未対応、 v0.3 で 対応 予定)
    const productCell = row.querySelector('.myo-list-orders-product-name-cell');
    if (!productCell) return null;

    const cellText = productCell.innerText || '';

    // 商品名 (最初 の a > div の text)
    const productLinkDiv = productCell.querySelector('a[href*="/gp/product/"] div');
    const product = productLinkDiv?.innerText?.trim() ||
                    cellText.split('\n')[0]?.trim() || '';

    // ASIN
    const asin = cellText.match(/ASIN[:：]\s*([A-Z0-9]{10})/)?.[1] || '';

    // SKU
    const sku = cellText.match(/SKU[:：]\s*(\S+)/)?.[1] || '';

    // 数量
    const qtyMatch = cellText.match(/数量[:：]\s*(\d+)/);
    const qty = qtyMatch ? parseInt(qtyMatch[1], 10) : 1;

    // 注文日
    const dateMatch = text.match(/(\d{4})\/(\d{1,2})\/(\d{1,2})/);
    const orderDate = dateMatch ? `${dateMatch[1]}/${dateMatch[2]}/${dateMatch[3]}` : '';

    if (!product || !buyer) {
      log('skip row (no product or buyer):', text.slice(0, 100));
      return null;
    }

    return { buyer, product, qty, orderId, asin, sku, orderDate };
  }

  // ─── page 上 全 rows scrape ─────────────────────────────
  function scrapePage() {
    const rows = document.querySelectorAll('table#orders-table tbody tr');
    log(`page rows detected: ${rows.length}`);
    const items = [];
    rows.forEach((row, i) => {
      const parsed = parseRow(row);
      if (parsed) items.push(parsed);
    });
    log(`  valid items: ${items.length}`);
    return items;
  }

  // ─── ページサイズ を 100 に 設定 (pagination 削減) ───────
  async function setMaxPageSize() {
    const sel = document.querySelector('select#myo-table-results-per-page');
    if (!sel) return false;
    if (sel.value === '100') return false;
    sel.value = '100';
    sel.dispatchEvent(new Event('change', { bubbles: true }));
    log('page size → 100');
    await sleep(3000);
    return true;
  }

  // ─── 「次へ」 が click 可能 か 判定 + click ────────────
  async function clickNextPage() {
    const nextLi = document.querySelector('ul.a-pagination li.a-last');
    if (!nextLi) return false;
    if (nextLi.classList.contains('a-disabled')) return false;

    const link = nextLi.querySelector('a');
    if (!link) return false;

    // scroll into view
    link.scrollIntoView({ block: 'center', behavior: 'instant' });
    await sleep(300);
    link.click();
    log('→ next page clicked');
    return true;
  }

  // ─── 全 page 巡回 ────────────────────────────────────
  async function scrapeAllPages(maxPages = 30) {
    // page size を 100 に 引き上げ (可能なら)
    const resized = await setMaxPageSize();
    if (resized) await sleep(2000);

    let all = [];
    let pageNum = 1;

    while (pageNum <= maxPages) {
      log(`=== page ${pageNum} ===`);
      await sleep(500);
      const items = scrapePage();
      all = all.concat(items);

      const moved = await clickNextPage();
      if (!moved) {
        log('no more pages, stop');
        break;
      }
      // 次 page の table render 待ち
      await sleep(2500);
      pageNum++;
    }

    return all;
  }

  // ─── 商品名 で group + sort ────────────────────────────
  function groupAndSort(items) {
    const groups = new Map();
    items.forEach(it => {
      // group key = 商品名 (SKU 違い は 別 group にしない、 見た目 で 判別)
      const key = it.product;
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(it);
    });

    // 各 group 内 は 個数多い順 → 名前順
    for (const arr of groups.values()) {
      arr.sort((a, b) => (b.qty - a.qty) || a.buyer.localeCompare(b.buyer, 'ja'));
    }

    // group 順: 合計個数多い順
    return Array.from(groups.entries())
      .map(([product, arr]) => ({
        product,
        total: arr.reduce((s, x) => s + x.qty, 0),
        asin: arr[0]?.asin || '',
        sku: arr[0]?.sku || '',
        buyers: arr,
      }))
      .sort((a, b) => b.total - a.total);
  }

  // ─── 印刷用 HTML 生成 ──────────────────────────────────
  function buildPrintHTML(groups) {
    const today = new Date();
    const dateStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
    const weekday = ['日', '月', '火', '水', '木', '金', '土'][today.getDay()];
    const timeStr = today.toLocaleTimeString('ja-JP', { hour: '2-digit', minute: '2-digit' });

    const totalItems = groups.reduce((s, g) => s + g.total, 0);
    const totalOrders = groups.reduce((s, g) => s + g.buyers.length, 0);

    const groupsHTML = groups.map(g => `
      <section class="group">
        <h2>
          <span class="pname">■ ${escapeHtml(g.product)}</span>
          <span class="qty">×${g.total}個</span>
        </h2>
        ${g.asin || g.sku ? `<div class="meta">${g.asin ? `ASIN ${escapeHtml(g.asin)}` : ''}${g.asin && g.sku ? '  /  ' : ''}${g.sku ? `SKU ${escapeHtml(g.sku)}` : ''}</div>` : ''}
        <ol>
          ${g.buyers.map((b, i) => `
            <li>
              <span class="num">${i + 1}.</span>
              <span class="buyer">${escapeHtml(b.buyer)} 様</span>
              <span class="q">×${b.qty}</span>
              <span class="oid">${escapeHtml(b.orderId)}</span>
            </li>
          `).join('')}
        </ol>
      </section>
    `).join('');

    return `<!DOCTYPE html>
<html lang="ja"><head>
<meta charset="UTF-8"><title>ピッキングリスト ${dateStr}</title>
<style>
  @page { size: A4 portrait; margin: 12mm; }
  * { box-sizing: border-box; }
  body { font-family: -apple-system, "Hiragino Kaku Gothic ProN", "Yu Gothic", sans-serif; color: #111; margin: 0; padding: 0; font-size: 11pt; line-height: 1.5; }
  header { border-bottom: 2px solid #000; padding: 0 0 6px; margin-bottom: 12px; display: flex; justify-content: space-between; align-items: baseline; }
  h1 { font-size: 14pt; margin: 0; font-weight: 700; }
  .meta-header { font-size: 10pt; color: #444; }
  .group { break-inside: avoid; page-break-inside: avoid; margin-bottom: 14px; }
  h2 { font-size: 12pt; margin: 6px 0 4px; padding: 5px 10px; background: #F2F2F2; border-left: 4px solid #000; display: flex; justify-content: space-between; align-items: baseline; font-weight: 700; }
  h2 .pname { flex: 1; padding-right: 12px; }
  h2 .qty { font-weight: 700; white-space: nowrap; }
  .meta { font-size: 9pt; color: #666; padding: 0 10px 4px; font-family: "SF Mono", Menlo, monospace; }
  ol { margin: 0; padding: 0; list-style: none; }
  li { padding: 4px 10px; border-bottom: 1px dotted #ccc; display: grid; grid-template-columns: 24px 1fr 60px 200px; gap: 8px; align-items: baseline; font-variant-numeric: tabular-nums; }
  li:last-child { border-bottom: 0; }
  .num { color: #999; font-size: 10pt; text-align: right; }
  .buyer { font-weight: 500; }
  .q { text-align: right; font-weight: 700; }
  .oid { font-family: "SF Mono", Menlo, monospace; font-size: 9pt; color: #666; }
  footer { margin-top: 16px; padding-top: 6px; border-top: 1px solid #999; text-align: right; font-size: 10pt; color: #666; }
  .print-btn { position: fixed; top: 12px; right: 12px; padding: 10px 16px; background: #FF9900; color: #000; border: 0; border-radius: 6px; cursor: pointer; font-weight: 600; box-shadow: 0 2px 6px rgba(0,0,0,0.2); }
  @media print { .print-btn { display: none !important; } }
</style>
</head><body>
<button class="print-btn" onclick="window.print()">印刷 (⌘P)</button>
<header>
  <h1>ピッキングリスト</h1>
  <div class="meta-header">${dateStr} (${weekday}) ${timeStr} — 未出荷 ${totalOrders}件 / 合計 ${totalItems}個</div>
</header>
${groupsHTML}
<footer>合計 ${totalItems}個 / ${totalOrders}件 — Jobs ピッキング拡張 v0.2</footer>
<script>setTimeout(() => window.print(), 500);</script>
</body></html>`;
  }

  function escapeHtml(s) {
    return String(s || '').replace(/[&<>"']/g, c => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[c]));
  }

  // ─── 外部 entry ────────────────────────────────────────
  window.__jobsPickingRun = async function () {
    try {
      log('start');
      const items = await scrapeAllPages();

      if (items.length === 0) {
        return { ok: false, error: '未出荷 row 検出 ゼロ。 URL 確認: /orders-v3/ 系 の 未出荷 tab を 開いてる か?' };
      }

      const groups = groupAndSort(items);
      log(`total: ${items.length} orders, ${groups.length} 商品 種`);

      const html = buildPrintHTML(groups);
      const blob = new Blob([html], { type: 'text/html' });
      const url = URL.createObjectURL(blob);
      window.open(url, '_blank');

      return {
        ok: true,
        itemCount: groups.length,
        orderCount: items.length,
      };
    } catch (e) {
      log('fatal:', e);
      return { ok: false, error: e.message + ' @ ' + e.stack?.split('\n')[1] };
    }
  };

  log('content.js v0.2 loaded, __jobsPickingRun ready');
})();
