// FP Compass 議事録レコーダー (Chrome拡張 MV3 service worker) v1.5.1
// 責務: FP Compass から 「顧客armed」 → Zoom タブで 拡張クリック → 自動録音開始 → Zoom閉じたら auto-stop + auto-send
// v1.5.1: STATE を chrome.storage.session に 永続化 (SW eviction 対策) + マイク設定ページ (setup.html)

const STATE = {
  recording: false,
  targetTabId: null,
  meta: null,
  armed: null,
  autoStartOnLoad: false,
  autoStartTabId: null,
};

// --- SW eviction 対策: STATE を session storage に mirror ---
async function persistState() {
  try {
    await chrome.storage.session.set({ __STATE: {
      recording: STATE.recording,
      targetTabId: STATE.targetTabId,
      meta: STATE.meta,
      armed: STATE.armed,
      autoStartOnLoad: STATE.autoStartOnLoad,
      autoStartTabId: STATE.autoStartTabId,
    }});
  } catch (e) { console.warn('persistState err', e); }
}

async function restoreState() {
  try {
    const { __STATE } = await chrome.storage.session.get('__STATE');
    if (__STATE) {
      Object.assign(STATE, __STATE);
      console.log('[bg] STATE restored from session storage:', STATE);
      if (STATE.armed && !STATE.recording) setBadgeArmed(STATE.armed.clientName);
      else if (STATE.recording) setBadgeRec(STATE.meta?.clientName);
    }
  } catch (e) { console.warn('restoreState err', e); }
}

// 起動 即 restore (SW re-spawn 時)
restoreState();

// --- badge helpers ---
function setBadgeIdle() {
  chrome.action.setBadgeText({ text: '' });
  chrome.action.setTitle({ title: 'FP Compass 議事録レコーダー' });
}
function setBadgeArmed(clientName) {
  chrome.action.setBadgeText({ text: '▶' });
  chrome.action.setBadgeBackgroundColor({ color: '#10B981' });
  chrome.action.setTitle({ title: `録音準備完了: ${clientName} さん — Zoom タブ で アイコン を クリック` });
}
function setBadgeRec(clientName) {
  chrome.action.setBadgeText({ text: 'REC' });
  chrome.action.setBadgeBackgroundColor({ color: '#DC2626' });
  chrome.action.setTitle({ title: `録音中: ${clientName || '(顧客未指定)'}` });
}

// --- offscreen ---
async function ensureOffscreen() {
  const existing = await chrome.offscreen.hasDocument?.();
  if (existing) return;
  await chrome.offscreen.createDocument({
    url: 'offscreen.html',
    reasons: ['USER_MEDIA', 'AUDIO_PLAYBACK'],
    justification: 'tab audio + mic 合成 録音 の ため MediaRecorder を 動かす',
  });
}

async function pickZoomTab() {
  const tabs = await chrome.tabs.query({});
  return tabs.find(t => /zoom\.(us|com)/i.test(t.url || '') && !t.discarded);
}

// --- 実 録音 開始 ---
async function startRecording(tabId, metaExtra = {}) {
  const zoomTab = await chrome.tabs.get(tabId);
  if (/^(chrome|edge|about|chrome-extension|view-source|devtools):/i.test(zoomTab.url || '')) {
    throw new Error('Chrome 内部ページ は 録音できません。 Zoom タブ を 開いてください。');
  }
  if (!/zoom\.(us|com)/i.test(zoomTab.url || '')) {
    // Zoom じゃなくても targetTabId として指定 OK なケース (Google Meet 等) だが、 現状 Zoom 限定
    throw new Error('このタブ は Zoom ではありません。 Zoom タブ に 切り替えてから 拡張アイコン を 押してください。');
  }

  const streamId = await new Promise((resolve, reject) => {
    chrome.tabCapture.getMediaStreamId({ targetTabId: zoomTab.id }, (id) => {
      if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
      if (!id) return reject(new Error('MediaStreamId 取得失敗。 Zoom タブ 上 で 拡張アイコン を 再度クリックしてください。'));
      resolve(id);
    });
  });

  await ensureOffscreen();
  const mergedMeta = {
    startedAt: Date.now(),
    ...(STATE.armed || {}),
    ...metaExtra,
  };

  const r = await chrome.runtime.sendMessage({
    target: 'offscreen', type: 'START', streamId, meta: mergedMeta,
  });
  if (r?.ok) {
    STATE.recording = true;
    STATE.targetTabId = zoomTab.id;
    STATE.meta = mergedMeta;
    setBadgeRec(mergedMeta.clientName);
    await persistState();
    // FP Compass タブ に 「録音開始したよ」 + micInfo を broadcast
    broadcastToFpTabs({ type: 'FP_RECORDING_STARTED', payload: {
      clientId: mergedMeta.clientId,
      clientName: mergedMeta.clientName,
      startedAt: mergedMeta.startedAt,
      micInfo: r.micInfo,
    }});
    // AirPods 無音 検知 は offscreen から MIC_WARNING で 別途 通知される
  }
  return r || { ok: false, error: 'offscreen 起動 失敗' };
}

async function stopRecording() {
  if (!STATE.recording) return { ok: false, error: '録音中 で ありません' };
  const r = await chrome.runtime.sendMessage({ target: 'offscreen', type: 'STOP' });
  STATE.recording = false;
  if (STATE.armed && STATE.meta?.clientName) setBadgeArmed(STATE.meta.clientName);
  else setBadgeIdle();
  await persistState();
  return r || { ok: false };
}

async function broadcastToFpTabs(payload) {
  try {
    const tabs = await chrome.tabs.query({ url: ['https://app.skeleton-inc.jp/*', 'https://stg.app.skeleton-inc.jp/*'] });
    for (const t of tabs) {
      try { await chrome.tabs.sendMessage(t.id, payload); } catch (_) {}
    }
  } catch (e) { console.error('broadcast err', e); }
}

// --- 主要 メッセージハンドラ ---
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    // FP Compass 側から 「この顧客で 録音を準備してくれ」
    if (msg.type === 'ARM_RECORDING') {
      STATE.armed = {
        clientId: msg.clientId,
        clientName: msg.clientName || '(名前未取得)',
        tenantId: msg.tenantId,
        armedAt: Date.now(),
        sourceTabId: sender.tab?.id,
      };
      setBadgeArmed(STATE.armed.clientName);
      await persistState();
      sendResponse({ ok: true, armed: STATE.armed });
      return;
    }

    if (msg.type === 'DISARM_RECORDING') {
      STATE.armed = null;
      if (!STATE.recording) setBadgeIdle();
      await persistState();
      sendResponse({ ok: true });
      return;
    }

    // popup から 「マイク設定 を 開く」
    if (msg.type === 'OPEN_MIC_SETUP') {
      try {
        const url = chrome.runtime.getURL('setup.html');
        // 既 に 開いてる setup タブ が あれば focus、 なければ 新規
        const tabs = await chrome.tabs.query({ url });
        if (tabs.length > 0) {
          await chrome.tabs.update(tabs[0].id, { active: true });
          await chrome.windows.update(tabs[0].windowId, { focused: true });
        } else {
          await chrome.tabs.create({ url, active: true });
        }
        sendResponse({ ok: true });
      } catch (e) {
        sendResponse({ ok: false, error: e.message });
      }
      return;
    }

    // popup から 「現在の mic 設定 を 取得」
    if (msg.type === 'GET_MIC_CONFIG') {
      const cfg = await chrome.storage.local.get([
        'preferredMicDeviceId', 'preferredMicLabel', 'preferredMicIsBluetooth', 'micSetupCompletedAt'
      ]);
      sendResponse({ ok: true, ...cfg });
      return;
    }

    // offscreen から の 警告 forward
    if (msg.type === 'MIC_WARNING' && msg.target === 'background') {
      broadcastToFpTabs({ type: 'FP_MIC_WARNING', payload: msg.payload });
      return;
    }

    // FP Compass 側 の 「Zoom 面談 開始」 button click → arm + Zoom タブ open + auto 録音予約
    if (msg.type === 'ARM_AND_OPEN_ZOOM') {
      try {
        STATE.armed = {
          clientId: msg.clientId,
          clientName: msg.clientName || '(名前未取得)',
          tenantId: msg.tenantId,
          armedAt: Date.now(),
          sourceTabId: sender.tab?.id,
        };
        setBadgeArmed(STATE.armed.clientName);
        const tab = await chrome.tabs.create({ url: msg.zoomUrl, active: true });
        STATE.autoStartOnLoad = true;
        STATE.autoStartTabId = tab.id;
        await persistState();
        sendResponse({ ok: true, armed: STATE.armed, tabId: tab.id, autoStart: true });
      } catch (e) {
        sendResponse({ ok: false, error: e.message });
      }
      return;
    }

    if (msg.type === 'START_RECORDING') {
      try {
        // popup から呼ばれる。 msg.tabId は popup で 検証済の Zoom タブ
        const targetId = msg.tabId || (await pickZoomTab())?.id;
        if (!targetId) return sendResponse({ ok: false, error: 'Zoom タブ が 見つかりません。' });
        const r = await startRecording(targetId, msg.meta || {});
        sendResponse(r);
      } catch (e) {
        sendResponse({ ok: false, error: e.message });
      }
      return;
    }

    if (msg.type === 'STOP_RECORDING') {
      sendResponse(await stopRecording());
      return;
    }

    if (msg.type === 'GET_STATE') {
      sendResponse({
        recording: STATE.recording,
        targetTabId: STATE.targetTabId,
        meta: STATE.meta,
        armed: STATE.armed,
      });
      return;
    }

    if (msg.type === 'RECORDING_DONE' && msg.target === 'background') {
      // offscreen が blob を base64 で 送ってきた → FP Compass タブ に 転送
      try {
        await broadcastToFpTabs({ type: 'FP_RECORDING_DONE', payload: msg.payload });
        STATE.armed = null;
        setBadgeIdle();
        await persistState();
      } catch (e) {
        console.error('forward RECORDING_DONE err', e);
      }
      return;
    }
  })();
  return true; // async
});

// --- Zoom タブ が 閉じられたら 自動停止 ---
chrome.tabs.onRemoved.addListener(async (tabId) => {
  if (STATE.recording && STATE.targetTabId === tabId) {
    console.log('Zoom タブ 閉鎖 検知 → 自動停止');
    await stopRecording();
  }
});

// --- Zoom タブ の URL が Zoom から離れたら 自動停止 ---
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (STATE.recording && STATE.targetTabId === tabId && changeInfo.url) {
    if (!/zoom\.(us|com)/i.test(changeInfo.url)) {
      console.log('Zoom タブ が 別 URL に 遷移 → 自動停止');
      await stopRecording();
    }
  }
  // 自動 開始: FP Compass から ARM_AND_OPEN_ZOOM で 開いた Zoom タブ の load 完了時
  if (STATE.autoStartOnLoad && STATE.autoStartTabId === tabId
      && changeInfo.status === 'complete'
      && /zoom\.(us|com)/i.test(tab?.url || '')
      && !STATE.recording) {
    STATE.autoStartOnLoad = false;
    await persistState();
    // 少し待つ (Zoom タブ の 音声 stream が 用意 されるまで)
    await new Promise(r => setTimeout(r, 1200));
    try {
      const r = await startRecording(tabId, {});
      console.log('[auto-start] recording started:', r);
      if (!r?.ok) {
        // user gesture 制約 で fail した 場合、 badge で 「クリックしてね」 表示
        setBadgeArmed(STATE.armed?.clientName || '(顧客未指定)');
        broadcastToFpTabs({
          type: 'FP_AUTO_START_FAILED',
          payload: { reason: r?.error || 'unknown', clientName: STATE.armed?.clientName }
        });
      }
    } catch (e) {
      console.error('[auto-start] failed:', e);
      setBadgeArmed(STATE.armed?.clientName || '(顧客未指定)');
      broadcastToFpTabs({
        type: 'FP_AUTO_START_FAILED',
        payload: { reason: e.message, clientName: STATE.armed?.clientName }
      });
    }
  }
});

// 起動時 に badge リセット
chrome.runtime.onStartup.addListener(setBadgeIdle);
chrome.runtime.onInstalled.addListener(setBadgeIdle);
