const $ = (id) => document.getElementById(id);
const ctxCard = $('ctx');
const clientNameEl = $('clientName');
const btnStart = $('btnStart');
const btnStop = $('btnStop');
const msg = $('msg');

let currentState = null;

async function refresh() {
  const s = await chrome.runtime.sendMessage({ type: 'GET_STATE' });
  currentState = s;

  // 顧客表示
  const clientName = s?.meta?.clientName || s?.armed?.clientName;
  if (clientName) {
    clientNameEl.textContent = clientName + ' さん';
    clientNameEl.className = 'card-value';
  } else {
    clientNameEl.textContent = '未選択 (FP Compass で「録音準備」ボタン を 押してください)';
    clientNameEl.className = 'card-value empty-state';
  }

  if (s?.recording) {
    ctxCard.className = 'card rec';
    btnStart.style.display = 'none';
    btnStop.style.display = 'block';
  } else if (s?.armed) {
    ctxCard.className = 'card armed';
    btnStart.style.display = 'block';
    btnStop.style.display = 'none';
    btnStart.textContent = `🎙 ${s.armed.clientName} さん の 録音 を 開始`;
  } else {
    ctxCard.className = 'card';
    btnStart.style.display = 'block';
    btnStop.style.display = 'none';
    btnStart.textContent = '🎙 録音 を 開始 (顧客未指定)';
  }
}

btnStart.addEventListener('click', async () => {
  msg.textContent = '';
  msg.className = '';
  btnStart.disabled = true;

  const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!activeTab) {
    msg.textContent = '❌ アクティブタブが取得できません';
    btnStart.disabled = false;
    return;
  }

  if (/^(chrome|edge|about|chrome-extension|moz-extension|view-source|devtools):/i.test(activeTab.url || '')) {
    msg.textContent = '❌ Chrome 内部ページ では 録音できません。 Zoom タブ を 開いて、 そのタブ上で 拡張機能アイコン を 押してください';
    btnStart.disabled = false;
    return;
  }

  if (!/zoom\.(us|com)/i.test(activeTab.url || '')) {
    msg.textContent = '❌ 現在のタブ が Zoom ではありません。 Zoom タブ に 切り替えて、 再度 拡張アイコン を クリックしてください';
    btnStart.disabled = false;
    return;
  }

  const r = await chrome.runtime.sendMessage({
    type: 'START_RECORDING',
    tabId: activeTab.id,
    meta: { startedAt: Date.now() }
  });
  btnStart.disabled = false;
  if (r?.ok) {
    msg.textContent = '✓ 録音開始';
    msg.className = 'ok';
    setTimeout(refresh, 200);
  } else {
    msg.textContent = '❌ ' + (r?.error || '開始できませんでした');
  }
});

btnStop.addEventListener('click', async () => {
  btnStop.disabled = true;
  msg.textContent = '';
  msg.className = '';
  const r = await chrome.runtime.sendMessage({ type: 'STOP_RECORDING' });
  btnStop.disabled = false;
  if (r?.ok) {
    msg.textContent = '✓ 停止しました。 FP Compass に 送信中…';
    msg.className = 'ok';
    setTimeout(refresh, 500);
  } else {
    msg.textContent = '❌ ' + (r?.error || '停止できませんでした');
  }
});

// --- Mic 設定 バナー ---
async function refreshMicBanner() {
  const banner = $('micBanner');
  const body = $('micBannerBody');
  try {
    const cfg = await chrome.runtime.sendMessage({ type: 'GET_MIC_CONFIG' });
    if (!cfg?.preferredMicDeviceId) {
      banner.className = 'mic-banner warn';
      banner.style.display = 'flex';
      body.innerHTML = '<b>初回セットアップ が 未完了。</b> AirPods や 内蔵mic を 確実 に 使う ため に <button class="link-btn" id="btnOpenSetup">マイク設定 を 開く</button> を お願いします。';
    } else {
      banner.className = 'mic-banner ok';
      banner.style.display = 'flex';
      const label = cfg.preferredMicLabel || 'マイク';
      const bt = cfg.preferredMicIsBluetooth ? ' <span style="opacity:0.7;">(Bluetooth)</span>' : '';
      body.innerHTML = `使用マイク: <b>${escapeHtml(label)}</b>${bt}  ·  <button class="link-btn" id="btnOpenSetup">変更</button>`;
    }
    const btn = $('btnOpenSetup');
    if (btn) btn.addEventListener('click', async () => {
      await chrome.runtime.sendMessage({ type: 'OPEN_MIC_SETUP' });
      window.close();
    });
  } catch (e) {
    console.warn('refreshMicBanner err', e);
  }
}
function escapeHtml(s) { return String(s||'').replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }

refresh();
refreshMicBanner();
