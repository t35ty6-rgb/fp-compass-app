const $ = (id) => document.getElementById(id);
const statusEl = $('status');
const btnStart = $('btnStart');
const btnStop = $('btnStop');
const msg = $('msg');

async function refresh() {
  const s = await chrome.runtime.sendMessage({ type: 'GET_STATE' });
  if (s?.recording) {
    statusEl.textContent = '録音 中';
    statusEl.className = 'status rec';
    btnStart.style.display = 'none';
    btnStop.style.display = 'block';
  } else {
    statusEl.textContent = '待機 中';
    statusEl.className = 'status';
    btnStart.style.display = 'block';
    btnStop.style.display = 'none';
  }
}

btnStart.addEventListener('click', async () => {
  msg.textContent = '';
  btnStart.disabled = true;
  const r = await chrome.runtime.sendMessage({ type: 'START_RECORDING', meta: { startedAt: Date.now() } });
  btnStart.disabled = false;
  if (r?.ok) { msg.textContent = ''; refresh(); }
  else msg.textContent = '❌ ' + (r?.error || '開始 できませんでした');
});

btnStop.addEventListener('click', async () => {
  btnStop.disabled = true;
  msg.textContent = '';
  const r = await chrome.runtime.sendMessage({ type: 'STOP_RECORDING' });
  btnStop.disabled = false;
  if (r?.ok) { msg.textContent = '✓ 停止 しました。 FP Compass に 送信 中…'; msg.className = 'ok'; refresh(); }
  else msg.textContent = '❌ ' + (r?.error || '停止 できませんでした');
});

refresh();
