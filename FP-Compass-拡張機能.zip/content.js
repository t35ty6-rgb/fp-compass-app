// content.js: FP Compass タブ に 注入 → 拡張存在 の 告知 と 音声 blob の 受け渡し

// 1) FP Compass ページ に 「拡張 install 済」 を 告知
(function announce() {
  const marker = document.createElement('meta');
  marker.name = 'fp-compass-tab-recorder';
  marker.content = chrome.runtime.getManifest().version;
  document.documentElement.appendChild(marker);
  // window スコープ にも window.__fpTabRecorder = version を 出す
  const s = document.createElement('script');
  s.textContent = 'window.__fpTabRecorder = ' + JSON.stringify(chrome.runtime.getManifest().version) + ';';
  (document.head || document.documentElement).appendChild(s);
  s.remove();
})();

// 2) 拡張 → ページ: 録音完了 blob を postMessage
chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === 'FP_RECORDING_DONE') {
    window.postMessage({
      source: 'fp-tab-recorder',
      type: 'RECORDING_DONE',
      payload: msg.payload,
    }, '*');
  }
});

// 3) ページ → 拡張: 録音 開始/停止 の トリガー を postMessage で 受ける
window.addEventListener('message', async (ev) => {
  if (ev.source !== window) return;
  const data = ev.data;
  if (!data || data.source !== 'fp-compass') return;
  if (data.type === 'REQUEST_START_TAB_RECORDING') {
    const r = await chrome.runtime.sendMessage({ type: 'START_RECORDING', meta: data.meta || {} });
    window.postMessage({ source: 'fp-tab-recorder', type: 'START_RESULT', payload: r }, '*');
  } else if (data.type === 'REQUEST_STOP_TAB_RECORDING') {
    const r = await chrome.runtime.sendMessage({ type: 'STOP_RECORDING' });
    window.postMessage({ source: 'fp-tab-recorder', type: 'STOP_RESULT', payload: r }, '*');
  } else if (data.type === 'PING_TAB_RECORDER') {
    window.postMessage({ source: 'fp-tab-recorder', type: 'PONG', payload: { version: chrome.runtime.getManifest().version } }, '*');
  }
});
