// FP Compass 議事録レコーダー (Chrome拡張 MV3 service worker)
// 責務: popup と content と offscreen の 仲介 + tabCapture MediaStreamId 発行

const STATE = { recording: false, tabId: null, targetTabId: null, meta: null };

async function ensureOffscreen() {
  const existing = await chrome.offscreen.hasDocument?.();
  if (existing) return;
  await chrome.offscreen.createDocument({
    url: 'offscreen.html',
    reasons: ['USER_MEDIA', 'AUDIO_PLAYBACK'],
    justification: 'tab audio + mic 合成 録音 の ため MediaRecorder を 動かす',
  });
}

async function pickZoomTab() {
  const tabs = await chrome.tabs.query({});
  return tabs.find(t => /zoom\.(us|com)/i.test(t.url || '') && !t.discarded);
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    if (msg.type === 'START_RECORDING') {
      try {
        const zoomTab = msg.tabId ? (await chrome.tabs.get(msg.tabId)) : await pickZoomTab();
        if (!zoomTab) return sendResponse({ ok: false, error: 'Zoom タブ が 見つかりません。 Zoom Web版 を 開いて ください。' });
        STATE.targetTabId = zoomTab.id;
        const streamId = await new Promise((resolve, reject) => {
          chrome.tabCapture.getMediaStreamId({ targetTabId: zoomTab.id }, (id) => {
            if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
            else resolve(id);
          });
        });
        await ensureOffscreen();
        const r = await chrome.runtime.sendMessage({
          target: 'offscreen', type: 'START', streamId, meta: msg.meta || {},
        });
        if (r?.ok) {
          STATE.recording = true;
          STATE.meta = msg.meta || {};
          chrome.action.setBadgeText({ text: 'REC' });
          chrome.action.setBadgeBackgroundColor({ color: '#DC2626' });
        }
        sendResponse(r || { ok: false, error: 'offscreen 起動 失敗' });
      } catch (e) {
        sendResponse({ ok: false, error: e.message });
      }
      return;
    }
    if (msg.type === 'STOP_RECORDING') {
      try {
        const r = await chrome.runtime.sendMessage({ target: 'offscreen', type: 'STOP' });
        STATE.recording = false;
        chrome.action.setBadgeText({ text: '' });
        sendResponse(r || { ok: false });
      } catch (e) {
        sendResponse({ ok: false, error: e.message });
      }
      return;
    }
    if (msg.type === 'GET_STATE') {
      sendResponse({ recording: STATE.recording, targetTabId: STATE.targetTabId, meta: STATE.meta });
      return;
    }
    if (msg.type === 'RECORDING_DONE' && msg.target === 'background') {
      // offscreen が blob を base64 で 送ってきたら FP Compass タブ に 転送
      try {
        const tabs = await chrome.tabs.query({ url: ['https://app.skeleton-inc.jp/*', 'https://stg.app.skeleton-inc.jp/*'] });
        for (const t of tabs) {
          try {
            await chrome.tabs.sendMessage(t.id, { type: 'FP_RECORDING_DONE', payload: msg.payload });
          } catch (_) {}
        }
      } catch (e) {
        console.error('forward RECORDING_DONE err', e);
      }
      return;
    }
  })();
  return true; // async
});

// content script からの直接ハンドシェイク応答
chrome.runtime.onMessageExternal.addListener((msg, sender, sendResponse) => {
  if (msg?.type === 'PING') sendResponse({ ok: true, version: chrome.runtime.getManifest().version });
});
