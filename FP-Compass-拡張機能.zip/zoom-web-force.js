// zoom-web-force.js — zoom.us タブ で 自動 「Web から参加」 click + アプリ起動 dialog dismiss
// tabCapture は Zoom Web でしか動かない ので、 Zoom App 起動 を 阻止 して Web モード に 固定

(function () {
  // 1) Zoom アプリ 起動 protocol handler (zoommtg:// 等) を intercept
  // ページ 読み込み時 に window.location = 'zoommtg://...' が 実行 されないように 監視
  try {
    const origSetter = Object.getOwnPropertyDescriptor(window.Location.prototype, 'href')?.set;
    if (origSetter) {
      Object.defineProperty(window.Location.prototype, 'href', {
        set(v) {
          if (typeof v === 'string' && /^zoommtg:/i.test(v)) {
            console.log('[zoom-web-force] blocked zoommtg:// launch → keeping Web mode');
            return; // don't call original setter
          }
          return origSetter.call(this, v);
        },
        configurable: true,
      });
    }
  } catch (e) { console.warn('[zoom-web-force] location intercept failed:', e); }

  // 2) 「Web から参加」 link / 「ブラウザで起動」 link を auto click (loop 5秒)
  const CLICK_TEXT_PATTERNS = [
    /ブラウザから参加|ブラウザから起動|Web から参加|Join from (Your |the )?Browser|Launch Meeting from Browser/i,
  ];
  const DISMISS_TEXT_PATTERNS = [
    /キャンセル|cancel|閉じる|close|dismiss/i,
  ];
  const tryClickJoin = () => {
    // 「ブラウザから参加」 系 link 探す
    const links = [...document.querySelectorAll('a, button, [role="button"]')];
    for (const el of links) {
      const t = (el.textContent || '').trim();
      if (!t) continue;
      if (CLICK_TEXT_PATTERNS.some(re => re.test(t))) {
        if (el.offsetParent !== null) {
          console.log('[zoom-web-force] auto-clicking:', t);
          el.click();
          return true;
        }
      }
    }
    return false;
  };
  const tryDismissAppDialog = () => {
    // 「Zoom を 開こうとして います」 dialog は Chrome native、 通常 DOM から touch できない
    // が、 一部の Zoom ページ内 の overlay は DOM に有るので dismiss を試みる
    const overlays = document.querySelectorAll('[class*="modal"], [class*="dialog"], [role="dialog"]');
    for (const ov of overlays) {
      const buttons = ov.querySelectorAll('button, a');
      for (const btn of buttons) {
        const t = (btn.textContent || '').trim();
        if (DISMISS_TEXT_PATTERNS.some(re => re.test(t))) {
          console.log('[zoom-web-force] dismissing overlay:', t);
          btn.click();
        }
      }
    }
  };

  // 5秒間、 500ms 毎 に auto-click 試行 (Zoom Web ページ 読み込み タイミング が バラつく ため)
  let attempts = 0;
  const iv = setInterval(() => {
    attempts++;
    if (attempts > 10) { clearInterval(iv); return; }
    if (tryClickJoin()) { clearInterval(iv); return; }
    tryDismissAppDialog();
  }, 500);

  // DOM ready 直後 も 1発 実行
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => setTimeout(() => { tryClickJoin(); tryDismissAppDialog(); }, 100));
  } else {
    setTimeout(() => { tryClickJoin(); tryDismissAppDialog(); }, 100);
  }
})();
